"""_summary_
"""

from typing import Union
from pyspark.sql import DataFrame
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DoubleType,
    FloatType,
    LongType,
    BooleanType,
    TimestampType,
    DateType
)

import admcore.utils as ut
import admcore.cbc.common.functions as cbc_func


# pylint: disable="W0613"
def common_table_loading(
        df: DataFrame,
        func_conf,
        table_conf,
        act_conf=None,
        pl_conf=None
):
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_): _description_
        act_conf (_type_): _description_
        pl_conf (_type_): _description_
    """
    table_name = table_conf.contract.table_name
    save_mode = func_conf.kwargs.save_mode

    cbc_func.create_table_by_contract(
        table_conf=table_conf,
        pl_conf=pl_conf,
        extra_columns=[]
    )

    # Try to convert data types of source to target
    table_schema: StructType = ut.AdmSpark.get_spark_session().table(table_name).schema
    df = df.to(table_schema)

    if save_mode == 'append':
        ut.AdmSpark.df_to_table_append(df, table_name)
    elif save_mode == 'overwrite':
        ut.AdmSpark.df_to_table_overwrite(df, table_name)
    elif save_mode == 'upsert':
        upsert_keys = func_conf.kwargs.upsert_keys
        ut.AdmSpark.df_to_table_upsert(
            df, upsert_keys, table_name
        )
    else:
        raise ut.AdmError("Invalid save_mode")


def df_to_delta_table(
        df: DataFrame,
        table_name: str,
        mode: str,
        upsert_keys: list[str] = None
):
    """spark>=3.4. This function will automatically convert the input DF to 
    make sure its schema lines up with table's

    Args:
        df (DataFrame): _description_
        table_name (str): _description_
        mode (str): _description_
        upsert_keys (list[str], optional): _description_. Defaults to None.
        table_schema (Union[dict, any], optional): _description_. Defaults to None.
    """

    table_schema: StructType = ut.AdmSpark.get_spark_session().table(table_name).schema
    df = df.to(table_schema)

    if mode == 'append':
        ut.AdmSpark.df_to_table_append(df, table_name)
    elif mode == 'overwrite':
        ut.AdmSpark.df_to_table_overwrite(df, table_name)
    elif mode == 'upsert':
        ut.AdmSpark.df_to_table_upsert(
            df, upsert_keys, table_name
        )
    else:
        raise ut.AdmError("Invalid writing mode")


def df_to_delta_table_with_manual_schema_mapping(
        df: DataFrame,
        table_name: str,
        mode: str,
        upsert_keys: list[str] = None,
        table_schema: Union[dict, any] = None
):
    """This function will automatically convert the input DF to 
    make sure its schema lines up with table's

    Args:
        df (DataFrame): _description_
        table_name (str): _description_
        mode (str): _description_
        upsert_keys (list[str], optional): _description_. Defaults to None.
        table_schema (Union[dict, any], optional): _description_. Defaults to None.
    """

    # Mapping from string to PySpark types
    type_mapping = {
        "string": StringType(),
        "integer": IntegerType(),
        "double": DoubleType(),
        "float": FloatType(),
        "long": LongType(),
        "boolean": BooleanType(),
        "timestamp": TimestampType(),
        "date": DateType()
    }

    if table_schema:
        struct_fields = [
            StructField(k, type_mapping[v.lower().split(' ')[0]], False)
            if 'not null' in v.lower()
            else StructField(k, type_mapping[v.lower().split(' ')[0]], True)
            for k, v in table_schema.items()
        ]
        existing_schema = StructType(struct_fields)

        df = df.select("*").toDF(*[f.name for f in existing_schema])

    if mode == 'append':
        ut.AdmSpark.df_to_table_append(df, table_name)
    elif mode == 'overwrite':
        ut.AdmSpark.df_to_table_overwrite(df, table_name)
    elif mode == 'upsert':
        ut.AdmSpark.df_to_table_upsert(
            df, upsert_keys, table_name
        )
    else:
        raise ut.AdmError("Invalid writing mode")
