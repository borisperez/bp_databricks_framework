"""_summary_
"""

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import StringType


# pylint: disable="W0613"
def remove_padded_zeros(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """
    override_column = func_conf.kwargs.options.get("override_column", False)
    #print(override_column)
    for col in func_conf.kwargs.columns:
        transformed_col = F.regexp_replace(
            F.col(col).cast(StringType()), r"^0+(?!$)", ""
        )
        if override_column:
            df = df.withColumn(col, transformed_col)
        else:
            new_col_name = f"{col}_shortcode"
            df = df.withColumn(new_col_name, transformed_col)

    return df
