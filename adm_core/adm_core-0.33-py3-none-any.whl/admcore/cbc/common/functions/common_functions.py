"""_summary_
"""

import functools
from pyspark.sql import DataFrame
from loguru import logger
import admcore.utils as ut


def get_output_view_name_in_function(
        func_conf
) -> str:
    """_summary_

    Args:
        func_conf (_type_): _description_

    Returns:
        str: _description_
    """
    output_view_name = (
        func_conf.kwargs.output_view_name
        if func_conf and ('output_view_name' in func_conf.kwargs and func_conf.kwargs.output_view_name is not None)
        else None
    )
    return output_view_name


def get_df_from_input_function(
        df,
        func_conf,
        action_conf
) -> DataFrame:
    """_summary_

    Args:
        df (Dataframe): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    input_func_conf = next(
        (item for item in action_conf.functions if item["name"] == func_conf.kwargs.input_function_name),
        None
    )

    #if input_func_conf is None:
    #    raise ut.AdmError(f"{func_conf.kwargs.input_function_name} is not found in Action {action_conf.name}")

    output_view_name = get_output_view_name_in_function(input_func_conf)

    if output_view_name:
        df_view = ut.AdmSpark.get_spark_session().sql(
            f"SELECT * FROM {output_view_name}"
        )
        logger.info(f"Get DataFrame from Spark temporary view '{output_view_name}'")

        return df_view

    return df


# pylint: disable=w0613
def add_session_variables(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
):
    """func_conf kwargs format
    kwargs:
      - variable_name: string
        variable_value: any

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    if 'kwargs' not in func_conf or isinstance(func_conf.kwargs, list) is False:
        raise ut.AdmError(f"Invalid config format in Function {func_conf.name}")

    for item in func_conf.kwargs:
        pl_conf.session_variables[item.variable_name] = item.variable_value


def df_input_output_wrapper(func):
    """_summary_

    Args:
        func (_type_): _description_

    Returns:
        _type_: _description_
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        df = get_df_from_input_function(args[0], args[1], args[2])

        new_args = (df, ) + args[1:]
        result = func(*new_args, **kwargs)

        output_view_name = get_output_view_name_in_function(args[1])
        if output_view_name:
            df.createOrReplaceGlobalTempView(name=output_view_name)
            result = None

        return result

    return wrapper
