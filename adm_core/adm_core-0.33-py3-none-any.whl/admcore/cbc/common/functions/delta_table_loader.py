"""_summary_
"""

from pyspark.sql.types import StructType

import admcore.utils as ut
import admcore.cbc.common.functions as adm_func


def load_table(
        df,
        extra_columns,
        func_conf,
        pl_conf
):
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    adm_func.create_table_by_contract(
        pl_conf=pl_conf,
        table_conf=func_conf.kwargs,
        extra_columns=extra_columns
    )

    # Try to convert data types of source to target
    table_schema: StructType = (
        ut.AdmSpark.get_spark_session()
            .table(func_conf.kwargs.contract.table_name)
            .schema
    )
    df = df.to(table_schema)

    adm_func.df_to_delta_table(
        df=df,
        table_name=func_conf.kwargs.contract.table_name,
        mode=func_conf.kwargs.save_mode,
        upsert_keys=func_conf.kwargs.upsert_keys
    )


# pylint: disable=w0613
def load_table_with_system_columns(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
):
    """This function will add _batch_id and _raw_file_name columns to the output table

    Args:
        df (Dataframe): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    df = adm_func.get_df_from_input_function(
        df=df,
        func_conf=func_conf,
        action_conf=action_conf
    )

    # Load data contract to func_conf
    if isinstance(func_conf.kwargs.contract, str) and (
        func_conf.kwargs.contract.endswith('.yml') or func_conf.kwargs.contract.endswith('.yaml')
    ):
        contract_conf = ut.AdmConfig.load_config_file(
                config_file_path=func_conf.kwargs.contract,
                session_variables=pl_conf.session_variables
        )
    else:
        contract_conf = func_conf.kwargs.contract

    # Get possibly extra column names from df
    contract_column_names = [column.name for column in contract_conf.schema.columns]
    extra_column_names = list(set(df.columns) - set(contract_column_names))

    extra_columns = [
        {
            'name': col_name, 
            'type': dtype,
            'description': 'System generated column'
        } for col_name, dtype in df.dtypes if col_name in extra_column_names
    ]

    load_table(
        df=df,
        extra_columns=extra_columns,
        func_conf=func_conf,
        pl_conf=pl_conf
    )

    # Return df to make sure next function can get it
    return df


def default_load_table(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
):
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Raises:
        ut.AdmError: _description_
    """
    df = adm_func.get_df_from_input_function(
        df=df,
        func_conf=func_conf,
        action_conf=action_conf
    )

    load_table(
        df=df,
        extra_columns=[],
        func_conf=func_conf,
        pl_conf=pl_conf
    )

    # Return df to make sure next function can get it
    return df
