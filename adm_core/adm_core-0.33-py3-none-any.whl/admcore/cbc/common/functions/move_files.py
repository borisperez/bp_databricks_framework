"""_summary_
"""


from pyspark.sql import DataFrame
from loguru import logger
import shutil
import os
from datetime import datetime
from pyspark.sql import SparkSession
import admcore.cbc.common.functions as cbc_func
from admcore.cbc.common.functions.common_functions import df_input_output_wrapper
import admcore.utils as ut

# pylint: disable="W0613"
@df_input_output_wrapper
def move_files(
    df: DataFrame,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """
    Function to move or archive files in ADLS using dbutils.fs.
    Works for unmounted paths (abfss://...).
    """
    logger.info("This is customized ADM function to move files from one location to another")

    source_path = func_conf.kwargs.source_path      # e.g., abfss://raw@storageaccount.dfs.core.windows.net/source/
    destination_path = func_conf.kwargs.destination_path
    operation_type = func_conf.kwargs.operation_type
    current_timestamp = pl_conf.session_variables.batch_id

    logger.info(f"File operation type is : {operation_type}")

    if operation_type.lower() == "move":
        target_path = destination_path
    elif operation_type.lower() == "archive":
        target_path = f"{destination_path.rstrip('/')}/{current_timestamp}"
    #spark = SparkSession.builder.getOrCreate()
    sp = ut.AdmSpark.get_spark_session()
    try:
        dbutils
    except NameError:
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(sp)
    # List files in source path
    try:
        files = dbutils.fs.ls(source_path)
        if not files:
            logger.warning(f"No files found in source path: {source_path}. Skipping file operation.")
            return df
    except Exception as e:
        logger.error(f"Error accessing source path {source_path}: {e}")
        return df

    # Ensure destination exists (not required, dbutils.fs.cp creates it automatically)
    for file_info in files:
        file_path = file_info.path
        file_name = os.path.basename(file_path.rstrip("/"))

        destination_file_path = f"{target_path.rstrip('/')}/{file_name}"

        try:
            if operation_type.lower() == "move":
                dbutils.fs.mv(file_path, destination_file_path)
                logger.info(f"Moved file {file_path} → {destination_file_path}")
            elif operation_type.lower() == "archive":
                dbutils.fs.cp(file_path, destination_file_path)
                dbutils.fs.rm(file_path)  # Remove after copy
                logger.info(f"Archived file {file_path} → {destination_file_path}")
        except Exception as e:
            logger.error(f"Failed to move/archive file {file_path}: {e}")

    return df