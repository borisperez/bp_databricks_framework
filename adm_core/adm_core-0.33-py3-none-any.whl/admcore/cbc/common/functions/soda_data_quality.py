"""_summary_
"""

import os
from datetime import datetime
import re

from soda.scan import Scan
from pyspark.sql import DataFrame
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, IntegerType
from loguru import logger

import admcore.utils as ut
import admcore.cbc.common.functions as adm_func


def get_create_soda_results_table(
        table_name: str
):
    """_summary_
    """
    runtime = os.environ['MFL_RUNTIME_ENV']

    sql = f"""
        CREATE {'EXTERNAL' if runtime=='local' else ''} TABLE IF NOT EXISTS {table_name} (
            git_repo_name STRING,
            pipeline_id STRING,
            pipeline_desc STRING,
            pipeline_file_path STRING,
            soda_config_file_path STRING,
            check_target_type STRING,
            check_target_name STRING,
            data_timestamp TIMESTAMP,
            scan_start_timestamp TIMESTAMP,
            scan_end_timestamp TIMESTAMP,
            soda_check_name STRING,
            soda_check_outcome STRING,
            soda_check_results STRING,
            retention_days INT
        )
        USING DELTA
        {'LOCATION ' + "'" + os.environ['MFL_LOCAL_DELTA_TABLE_PATH'] + '/' + table_name + "'" if runtime=='local' else ''}
    """

    ut.AdmSpark.get_spark_session().sql(sql)


def get_common_results(
        func_conf,
        task_conf,
        pl_conf,
        json_results
) -> list:
    """_summary_

    Args:
        func_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
        json_results (_type_): _description_

    Returns:
        list: _description_
    """

    results = [
        os.environ['MFL_GIT_REPO_NAME'],
        pl_conf.info.enterprise_id,
        pl_conf.info.desc,
        pl_conf.info.pipeline_file_path,
        func_conf.kwargs.soda_config_file_path,
        func_conf.kwargs.audit.check_target_type,
        func_conf.kwargs.audit.check_target_name,
        datetime.fromisoformat(json_results['dataTimestamp']),
        datetime.fromisoformat(json_results['scanStartTimestamp']),
        datetime.fromisoformat(json_results['scanEndTimestamp'])
    ]

    return results


def save_check_results(
        func_conf,
        task_conf,
        pl_conf,
        json_results,
        abnormal_text_results: str=None
):
    """_summary_

    Args:
        func_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
        json_results (_type_): _description_
        abnormal_text_results (str, optional): _description_. Defaults to None.
    """

    results = []

    # Get passed items
    checks_size = len(json_results['checks'])
    for n in range(checks_size):
        if json_results['checks'][n]['outcome'] == 'pass':
            record = get_common_results(
                func_conf=func_conf,
                task_conf=task_conf,
                pl_conf=pl_conf,
                json_results=json_results
            )
            record.extend([
                json_results['checks'][n]['name'],
                json_results['checks'][n]['outcome'],
                None,
                func_conf.kwargs.audit.retention_days
            ])
            results.append(record)

    # Get fail/warn items
    if abnormal_text_results:
        lines = abnormal_text_results.split('\n')
        for line in lines:
            match = re.match(r"\[(.*?)\]\s+(\w+)\s+\((.*?)\)", line)
            if not match:
                raise ut.AdmError(f"Unexpected Soda result format: {line}")
            items = list(match.groups())

            record = get_common_results(
                func_conf=func_conf,
                task_conf=task_conf,
                pl_conf=pl_conf,
                json_results=json_results
            )
            record.extend([
                items[0].strip('[').strip(']'),
                items[1].lower(),
                items[2].strip('(').strip(')'),
                func_conf.kwargs.audit.retention_days
            ])

            results.append(record)

    # Create Spark dataframe
    df = ut.AdmSpark.get_spark_session().createDataFrame(
        data=results,
        schema=StructType([
            StructField("git_repo_name", StringType(), True),
            StructField("pipeline_id", StringType(), True),
            StructField("pipeline_desc", StringType(), True),
            StructField("pipeline_file_path", StringType(), True),
            StructField("soda_config_file_path", StringType(), True),
            StructField("check_target_type", StringType(), True),
            StructField("check_target_name", StringType(), True),
            StructField("data_timestamp", TimestampType(), True),
            StructField("scan_start_timestamp", TimestampType(), True),
            StructField("scan_end_timestamp", TimestampType(), True),
            StructField("soda_check_name", StringType(), True),
            StructField("soda_check_outcome", StringType(), True),
            StructField("soda_check_results", StringType(), True),
            StructField("retention_days", IntegerType(), True),
        ])
    )

    table_name = f"{os.environ['MFL_SKM_AUDIT']}.adm_soda_check_results"
    get_create_soda_results_table(table_name=table_name)
    adm_func.df_to_delta_table(
        df=df,
        table_name=table_name,
        mode='append'
    )


def quality_check(
        func_conf,
        task_conf,
        pl_conf,
        input_df=None
):
    """_summary_

    Args:
        func_conf (_type_): _description_
        input_df (_type_, optional): _description_. Defaults to None.

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_
        ut.AdmError: _description_
    """

    soda_config = ut.AdmConfig.load_config_file(
        func_conf.kwargs.soda_config_file_path,
        session_variables=None
    )

    for item in soda_config.to_dict():
        check_def = item.lower()
        if 'checks for' in check_def:
            view_name = check_def.split(' ')[-1]
            sp = ut.AdmSpark.get_spark_session()

            if input_df:
                input_df.createOrReplaceTempView(view_name)
            elif func_conf.kwargs.table_name:
                sp.sql(f"select * from {func_conf.kwargs.table_name}").createOrReplaceTempView(view_name)
            else:
                raise ut.AdmError("input_df and input_table_name can't be all None")

            scan = Scan()
            if func_conf.kwargs.verbose:
                scan.set_verbose(True)
            scan.set_scan_definition_name(check_def)
            scan.set_data_source_name(view_name)

            scan.add_spark_session(sp, data_source_name=view_name)
            scan.add_sodacl_yaml_file(file_path=func_conf.kwargs.soda_config_file_path)

            scan.execute()

            if func_conf.kwargs.verbose:
                logger.info(scan.get_all_checks_text())

            abnormal_check_results = None
            if scan.has_check_warns_or_fails():
                abnormal_check_results = scan.get_checks_warn_or_fail_text()
                lines = abnormal_check_results.split('\n')
                for line in lines:
                    if line.find('FAIL') > 0:
                        logger.error(line)
                    else:
                        logger.warning(line)

            if 'audit' in func_conf.kwargs:
                logger.info('Saving audit information started...')
                save_check_results(
                    func_conf=func_conf,
                    task_conf=task_conf,
                    pl_conf=pl_conf,
                    json_results=scan.get_scan_results(),
                    abnormal_text_results=abnormal_check_results
                )
                logger.info('Saving audit information finished')

            if len(scan.get_error_logs()) > 0:
                raise ut.AdmError(scan.get_error_logs_text())

            if scan.has_check_fails():
                raise ut.AdmError(scan.get_checks_fail_text())


#pylint: disable=w0613
def dataframe_quality_check_by_soda(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
) -> DataFrame:
    """This function performs data quality check against an input Spark dataframe or a view defined in func_conf

    Args:
        df (Dataframe): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    df = adm_func.get_df_from_input_function(
        df,
        func_conf=func_conf,
        action_conf=action_conf
    )

    quality_check(
        func_conf=func_conf,
        task_conf=task_conf,
        pl_conf=pl_conf,
        input_df=df
    )

    return df

#pylint: disable=w0613
def table_quality_check_by_soda(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
) -> DataFrame:
    """This function performs data quality check against an input Spark dataframe or a view defined in func_conf

    Args:
        df (Dataframe): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    quality_check(
        func_conf=func_conf,
        task_conf=task_conf,
        pl_conf=pl_conf
    )

    return df
