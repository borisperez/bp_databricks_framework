"""_summary_
"""

from pyspark.sql import DataFrame
from soda.contracts.contract_verification import ContractVerification

import admcore.utils as ut


# pylint: disable="W0613"
def data_contract_validation(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_

    Returns:
        DataFrame: _description_
    """

    soda_contract_file_path = func_conf.kwargs.soda_contract_file_path
    input_dataset_type = func_conf.kwargs.input_dataset_type

    soda_contract_config = ut.AdmConfig.load_config_file(
        soda_contract_file_path,
        session_variables=pl_conf.session_variables
    )

    if input_dataset_type == 'file':
        df.createOrReplaceTempView(
            name=soda_contract_config.dataset
        )
    elif input_dataset_type == 'table':
        pass
    else:
        raise ut.AdmError(f"Invalid input_dataset_type: {input_dataset_type}")

    contract_verification: ContractVerification = (
        ContractVerification.builder()
            .with_contract_yaml_file(soda_contract_file_path)
            .with_data_source_spark_session(ut.AdmSpark.get_spark_session())
            .execute()
    )

    for result in contract_verification.contract_results:
        print(result)
        if result.failed():
            raise ut.AdmError(f"Input data quality check failed: {result}")
