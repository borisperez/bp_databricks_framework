"""_summary_
"""

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import StringType


# pylint: disable="W0613"
def handle_null_values(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """
    numeric_placeholder = func_conf.kwargs.options.get("numeric_null_placeholder", 0)
    string_placeholder = func_conf.kwargs.options.get("string_null_placeholder", "")

    for col in func_conf.kwargs.columns:
        col_type = df.schema[col].dataType
        if isinstance(col_type, StringType):
            df = df.withColumn(
                col,
                F.when(F.col(col).isNull(), F.lit(string_placeholder)).otherwise(
                    F.col(col)
                ),
            )
        else:
            df = df.withColumn(
                col,
                F.when(F.col(col).isNull(), F.lit(numeric_placeholder)).otherwise(
                    F.col(col)
                ),
            )

    return df
