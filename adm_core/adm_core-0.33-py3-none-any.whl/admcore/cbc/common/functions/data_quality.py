"""_summary_
"""

from soda.scan import Scan
from pyspark.sql import DataFrame
import admcore.utils as ut


def data_quality_check_by_soda(
        df: DataFrame,
        func_conf,
        act_conf,
        task_conf,
        pl_conf
):
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        act_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_
    """
    soda_config = ut.AdmConfig.load_config_file(
        func_conf.kwargs.soda_config_file_path,
        session_variables=None
    )

    for item in soda_config.to_dict():
        check_def = item.lower()
        if 'checks for' in check_def:
            view_name = check_def.split(' ')[-1]
            if func_conf.kwargs.input_dataset_type == 'file':
                df.createOrReplaceTempView(
                    name=view_name
                )
            else:
                raise ut.AdmError(f"Invalid input_dataset_type: {func_conf.kwargs.input_dataset_type}")

            scan = Scan()
            if act_conf.kwargs.verbose:
                scan.set_verbose(True)
            scan.set_scan_definition_name(check_def)
            scan.set_data_source_name(view_name)

            sp = ut.AdmSpark.get_spark_session()
            scan.add_spark_session(sp, data_source_name=view_name)
            scan.add_sodacl_yaml_file(file_path=act_conf.kwargs.soda_config_file_path)

            scan.execute()

            # Could cause "Spark function is not whitelisted" error in some computes
            #sp.catalog.dropTempView(view_name)

            if len(scan.get_error_logs()) > 0:
                raise ut.AdmError(scan.get_error_logs_text())

            if len(scan.get_checks_fail()) > 0:
                raise ut.AdmError(scan.get_checks_fail_text())
