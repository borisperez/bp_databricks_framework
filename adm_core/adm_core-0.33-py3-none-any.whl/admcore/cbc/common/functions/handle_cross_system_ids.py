"""_summary_
"""

from pyspark.sql import DataFrame, functions as F


# pylint: disable="W0613"
def handle_cross_system_ids(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """
    primary_system = func_conf.kwargs.options.get("primary_system", "SAP")
    secondary_system = func_conf.kwargs.options.get("secondary_system", "Salesforce")
    sap_id_column = func_conf.kwargs.options.get("sap_id_column", "sap_customer_id")
    salesforce_id_column = func_conf.kwargs.options.get("salesforce_id_column", "sf_account_id")

    for col in func_conf.kwargs.columns:
        if sap_id_column in df.columns and salesforce_id_column in df.columns:
            df = df.withColumn(
                col,
                F.when(
                    F.col(sap_id_column).isNotNull(), F.col(sap_id_column)
                ).otherwise(F.col(salesforce_id_column)),
            )

    return df
