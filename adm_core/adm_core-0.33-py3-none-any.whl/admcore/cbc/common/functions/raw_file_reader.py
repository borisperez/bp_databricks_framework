"""_summary_
"""


from datetime import datetime
import os

from loguru import logger

import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql import DataFrame
from pyspark.sql.types import StructType
from pyspark.errors.exceptions.captured import AnalysisException

from admcore.cbc.common.functions.common_functions import df_input_output_wrapper
import admcore.utils as ut
import admcore.cbc.common.functions as adm_func


#pylint: disable=w0613
def spark_read_csv_files(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
) -> DataFrame:
    """This function reads all csv files based on input path pattern.
       It'll return a Dataframe if it can't find output_view_name in the config.

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    if "path_pattern" not in func_conf.kwargs or func_conf.kwargs.path_pattern is None:
        raise ut.AdmError(f"Function {func_conf.name} missing path_pattern config item")

    batch_id = pl_conf.session_variables.batch_id
    file_path = func_conf.kwargs.path_pattern
    spark_kwargs = func_conf.kwargs.kwargs

    path_not_found: bool = (
        func_conf.kwargs.warn_path_not_found if 'warn_path_not_found' in func_conf.kwargs else False
    )

    logger.info(f"Read CSV files by path pattern: {file_path}")

    sp = ut.AdmSpark.get_spark_session()

    try:
        df: DataFrame = sp.read.csv(
            path=file_path,
            **spark_kwargs
        )

        df = ut.AdmSpark.replace_invalid_chars_in_col_names(df)

        df = df.withColumn("_raw_file_name", F.col("_metadata.file_name"))
        df = df.withColumn("_batch_id", F.lit(batch_id))

        output_view_name = adm_func.get_output_view_name_in_function(func_conf)
        if output_view_name:
            df.createOrReplaceTempView(name=output_view_name)

        return df
    except AnalysisException as e:
        if e.desc.startswith("[PATH_NOT_FOUND]") and path_not_found:
            logger.warning(f"No files found for path pattern {file_path}")
        else:
            raise e


# pylint: disable="W0613"
def pandas_load_excel_with_meta_info(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_

    Returns:
        DataFrame: _description_
    """

    batch_id = pl_conf.session_variables.batch_id
    raw_file_path = func_conf.kwargs.path
    pandas_kwargs = func_conf.kwargs.kwargs

    sdf_all = ut.AdmSpark.get_spark_session().createDataFrame([], StructType([]))

    for file_name in os.listdir(raw_file_path):
        file_path = os.path.join(raw_file_path, file_name)
        if os.path.isfile(file_path) and file_name.endswith(('.xlsx', '.xls', '.xlsm')):
            logger.info(f"Pandas read excel file: {file_path}")
            # Make sure converting all columns to str safely
            if 'dtype' not in pandas_kwargs:
                pandas_kwargs['dtype'] = 'object'
            df = (
                    pd.read_excel(file_path, **pandas_kwargs)
                        .astype(str)
                        .apply(lambda x: x.str.strip())
                )

            sdf = ut.AdmSpark.get_spark_session().createDataFrame(df)

            sdf = ut.AdmSpark.replace_invalid_chars_in_col_names(sdf)

            timestamp = os.path.getmtime(file_path)
            last_modified = datetime.fromtimestamp(timestamp)
            sdf = sdf.withColumn("_upload_time", F.lit(last_modified))

            sdf = sdf.withColumn("_raw_file_name", F.lit(file_name))
            sdf = sdf.withColumn("_batch_id", F.lit(batch_id))

            excel_file = pd.ExcelFile(file_path)
            sheet_names = excel_file.sheet_names

            if isinstance(pandas_kwargs['sheet_name'], str):
                # sheet name is used in kwargs instead of sheet number
                sheet_number = sheet_names.index(pandas_kwargs['sheet_name'])
            else:
                sheet_number = pandas_kwargs['sheet_name']

            sdf = sdf.withColumn("_sheet_name", F.lit(sheet_names[sheet_number]))

            if sdf_all.isEmpty():
                sdf_all = sdf
            else:
                sdf_all = sdf_all.union(sdf)
        else:
            raise ut.AdmError("Invalid raw file format")

    output_view_name = adm_func.get_output_view_name_in_function(func_conf)
    if output_view_name:
        sdf_all.createOrReplaceTempView(name=output_view_name)

    return None if sdf_all.isEmpty() else sdf_all


@df_input_output_wrapper
def spark_read_json_files(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
) -> DataFrame:
    """A basic JSON file reader. 
    It loads all JSON files with a certain path pattern to a single Spark DataFrame.
    It doesn't do any transformations to the raw data except changing invalid column names.
    It also adds two system columns _raw_file_name and _batch_id

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    if "path_pattern" not in func_conf.kwargs or func_conf.kwargs.path_pattern is None:
        raise ut.AdmError(f"Function {func_conf.name} missing path_pattern config item")

    batch_id = pl_conf.session_variables.batch_id
    file_path = func_conf.kwargs.path_pattern

    if "kwargs" in func_conf.kwargs and func_conf.kwargs.kwargs is not None:
        spark_kwargs = func_conf.kwargs.kwargs
    else:
        spark_kwargs = {}

    logger.info(f"Read JSON files by path pattern: {file_path}")

    sp = ut.AdmSpark.get_spark_session()
    df: DataFrame = sp.read.json(
        path=file_path,
        **spark_kwargs
    )

    df = ut.AdmSpark.replace_invalid_chars_in_col_names(df)

    df = df.withColumn("_raw_file_name", F.col("_metadata.file_name"))
    df = df.withColumn("_batch_id", F.lit(batch_id))

    return df
