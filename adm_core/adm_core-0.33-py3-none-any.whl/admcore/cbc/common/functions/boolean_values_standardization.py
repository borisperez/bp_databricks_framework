"""_summary_
"""

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import StringType, BooleanType


# pylint: disable="W0613"
def boolean_values_standardization(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """

    true_values = func_conf.kwargs.options.get("true_values", ["1", "y", "yes"])
    false_values = func_conf.kwargs.options.get("false_values", ["0", "n", "x"])

    for col in func_conf.kwargs.columns:
        df = df.withColumn(col, F.col(col).cast(StringType()))
        df = df.withColumn(
            col,
            F.when(F.col(col).isin(true_values), F.lit(True))
            .when(F.col(col).isin(false_values), F.lit(False))
            .otherwise(
                F.lit(None).cast(BooleanType())
            ),  # Handle malformed data by setting to None
        )

    return df
