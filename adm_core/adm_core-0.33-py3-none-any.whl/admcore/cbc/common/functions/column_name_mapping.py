"""_summary_
"""

from pyspark.sql import (
    DataFrame,
    functions as F
)


# pylint: disable="W0613"
def column_name_mapping(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """

    if func_conf.enable is True and bool(func_conf.kwargs) is True:
        col_mapping = {}

        for key, value in func_conf.kwargs.items():
            if value not in col_mapping:
                col_mapping[value] = [key]
            else:
                col_mapping[value].append(key)

        # Change column names if one-one mapping
        col_mapping_one_one = {
            k: ''.join(v) for k, v in col_mapping.items() if len(v) == 1
        }
        df = df.select(
            [F.col(c).alias(col_mapping_one_one.get(c, c)) for c in df.columns]
        )

        # Add new columns if one-to-many mapping
        col_mapping_one_many = {
            k: v for k, v in col_mapping.items() if len(v) > 1
        }
        for k, v in col_mapping_one_many.items():
            for v1 in v:
                df = df.withColumn(v1, F.col(k))

    return df
