"""_summary_
"""


from datetime import datetime, timezone
import os
import pandas as pd
import pyspark.sql.functions as F
from loguru import logger
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from pyspark.sql.types import StringType

from admcore.cbc.common.functions.delta_table_loader import load_table_with_system_columns
import admcore.utils as ut
from admcore.cbc.common.functions.common_functions import df_input_output_wrapper
import admcore.cbc.common.functions as adm_func
import admcore.utils as ut


# pylint: disable="W0613"

def pandas_excel_to_table_with_meta_info(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_

    Returns:
        DataFrame: _description_
    """

    batch_id = pl_conf.session_variables.batch_id
    raw_file_path = func_conf.kwargs.path
    pandas_kwargs = func_conf.kwargs.kwargs

    for file_name in os.listdir(raw_file_path):
        file_path = os.path.join(raw_file_path, file_name)
        if os.path.isfile(file_path) and file_name.endswith(('.xlsx', '.xls', '.xlsm')):
            logger.info(f"Pandas read excel file: {file_path}")
            # Make sure converting all columns to str safely
            if 'dtype' not in pandas_kwargs:
                pandas_kwargs['dtype'] = 'object'
            df = (
                    pd.read_excel(file_path, **pandas_kwargs)
                        .astype(str)
                        .apply(lambda x: x.str.strip())
                )

            sdf = ut.AdmSpark.get_spark_session().createDataFrame(df)

            sdf = ut.AdmSpark.replace_invalid_chars_in_col_names(sdf)

            timestamp = os.path.getmtime(file_path)
            last_modified = datetime.fromtimestamp(timestamp)
            sdf = sdf.withColumn("_upload_time", F.lit(last_modified))

            sdf = sdf.withColumn("_raw_file_name", F.lit(file_name))
            sdf = sdf.withColumn("_batch_id", F.lit(batch_id))

            excel_file = pd.ExcelFile(file_path)
            sheet_names = excel_file.sheet_names

            if isinstance(pandas_kwargs['sheet_name'], str):
                # sheet name is used in kwargs instead of sheet number
                sheet_number = sheet_names.index(pandas_kwargs['sheet_name'])
            else:
                sheet_number = pandas_kwargs['sheet_name']

            sdf = sdf.withColumn("_sheet_name", F.lit(sheet_names[sheet_number]))

            load_table_with_system_columns(
                df=sdf,
                func_conf=func_conf,
                action_conf=action_conf,
                task_conf=task_conf,
                pl_conf=pl_conf
            )

        else:
            raise ut.AdmError("Invalid raw file format")

    return None

@df_input_output_wrapper
def load_parquet_files_to_table_with_read_method(
    df: DataFrame,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    logger.info("Starting function: load_parquet_files_to_table_with_read_method")

    batch_id = pl_conf.session_variables.batch_id
    raw_file_path = func_conf.kwargs.path  # Can be abfss:// or /mnt/...
    
    spark_kwargs = func_conf.kwargs.get("kwargs", {})
    file_read_method = func_conf.kwargs.get("file_read_method", "default")
    file_data_sort_key_columns = func_conf.kwargs.get("file_data_sort_key_columns", [])

    spark = ut.AdmSpark.get_spark_session()
    dataframes = []
    try:
        dbutils
    except NameError:
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(spark)
    # List files in the directory
    try:
        files_info = dbutils.fs.ls(raw_file_path)
        parquet_files = [f for f in files_info if f.name.endswith(".parquet")]
    except Exception as e:
        logger.error(f"Could not list files at {raw_file_path}: {e}")
        return None

    if not parquet_files:
        logger.warning("No Parquet files found to process.")
        return None

    # Sort by last modified timestamp
    parquet_files.sort(key=lambda f: f.modificationTime)

    for file_info in parquet_files:
        file_path = file_info.path
        file_name = file_info.name
        #last_modified = datetime.utcfromtimestamp(file_info.modificationTime / 1000)
        last_modified = datetime.fromtimestamp(file_info.modificationTime / 1000, tz=timezone.utc)
        
        logger.info(f"Reading Parquet file: {file_path} ,last modified at: {last_modified}")
        sdf = spark.read.parquet(file_path, **spark_kwargs)

        # Cast all columns to StringType
        for col_name in sdf.columns:
            sdf = sdf.withColumn(col_name, F.col(col_name).cast(StringType()))

        sdf = ut.AdmSpark.replace_invalid_chars_in_col_names(sdf)

        # Add metadata
        sdf = sdf.withColumn("_upload_time", F.lit(last_modified))
        sdf = sdf.withColumn("_raw_file_name", F.lit(file_name))
        sdf = sdf.withColumn("_batch_id", F.lit(batch_id))

        dataframes.append(sdf)

    if not dataframes:
        logger.warning("No dataframes to load.")
        return None

    combined_df = dataframes[0]
    for sdf in dataframes[1:]:
        combined_df = combined_df.unionByName(sdf, allowMissingColumns=True)

    if combined_df.limit(1).count() == 0:
        logger.warning("Combined dataframe is empty.")
        return None

    # Optionally select latest records
    if file_read_method == "sort_select_latest" and file_data_sort_key_columns:
        logger.info("Applying sort_select_latest logic...")
        window_spec = Window.partitionBy(*file_data_sort_key_columns).orderBy(F.col("_upload_time").desc())
        combined_df = combined_df.withColumn("_row_number", F.row_number().over(window_spec))
        combined_df = combined_df.filter(F.col("_row_number") == 1).drop("_row_number")

    # Load to destination table
    load_table_with_system_columns(
        df=combined_df,
        func_conf=func_conf,
        action_conf=action_conf,
        task_conf=task_conf,
        pl_conf=pl_conf
    )

    return combined_df
