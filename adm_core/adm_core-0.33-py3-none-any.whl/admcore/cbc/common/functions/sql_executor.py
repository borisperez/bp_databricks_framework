"""Define all functions to run SQL scripts configured in files
"""

from pyspark.sql import DataFrame

from admcore.cbc.common.functions.common_functions import df_input_output_wrapper
import admcore.utils as ut
import admcore.cbc.common.functions as adm_func

from loguru import logger

def get_sql_script(
        func_conf,
        pl_conf
) -> str:
    """_summary_

    Args:
        func_conf (_type_): _description_
        pl_conf (_type_): _description_

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_

    Returns:
        str: _description_
    """

    if 'sql' not in func_conf.kwargs or func_conf.kwargs.sql is None:
        raise ut.AdmError(f"sql entry missing in Function {func_conf.name} kwargs config")

    if func_conf.kwargs.sql.endswith('yml') or func_conf.kwargs.sql.endswith('yaml'):
        sql_script_conf = ut.AdmConfig.load_config_file(
            config_file_path=func_conf.kwargs.sql,
            session_variables=pl_conf.session_variables
        )

        if 'sql' not in sql_script_conf:
            raise ut.AdmError(f"sql entry missing in sql config file {func_conf.kwargs.sql}")

        sql_script = sql_script_conf.sql
    else:
        sql_script = func_conf.kwargs.sql

    return sql_script

# pylint: disable=w0613
def default_sql_query(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """
    sp = ut.AdmSpark.get_spark_session()

    sql_script = get_sql_script(func_conf, pl_conf)

    # Check if create view statement is in sql_script for backward compatibility.
    if sql_script.strip().upper().startswith("CREATE OR REPLACE TEMPORARY VIEW") is False:
        # sql_script is a query. Use func_conf.kwargs.output_view_name to create view
        # if it's configured or just return a DF
        output_view_name = adm_func.get_output_view_name_in_function(func_conf)
        if output_view_name:
            sql_script = f"CREATE OR REPLACE TEMPORARY VIEW {output_view_name} AS {sql_script}"
            sp.sql(sql_script)
            return None

    df = sp.sql(sql_script)
    return df

def default_sql_modification(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
):
    """Run SQLs like update or delete

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
    """
    sql_script = get_sql_script(func_conf, pl_conf)

    sp = ut.AdmSpark.get_spark_session()
    sp.sql(sql_script)
    
    # Return df to make sure next function can get it
    return df

@df_input_output_wrapper
def execute_sql_if_table_exists(
    df: DataFrame,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """Your function has to follow the same function declaration. 
    And the positional arguments have to be in the same order as this example.

    Args:
        df (DataFrame): Spark dataframe passed from upstream Functions. Could be None.
        func_conf (_type_): Function configuration part in YAML config file
        action_conf (_type_): Function configuration part in YAML config file
        task_conf (_type_, optional): The entire task configuration in YAML config file
        pl_conf (_type_, optional): All configuration in pipeline.yml file

    Returns:
        DataFrame: Spark dataframe
    """
    logger.info("This functions executes the input sql when tables exist")

    # Example: Get Spark session
    sp = ut.AdmSpark.get_spark_session()

    # defining function parameters
    tables = func_conf.kwargs.get("table_list", [])
    sql_script = get_sql_script(func_conf, pl_conf)
 
       
    # Split and trim table names
    table_list = [tbl.strip() for tbl in tables]
    
    # Track missing tables
    missing_tables = []

    for table in table_list:
        if sp.catalog.tableExists(table):
            pass
        else:
            missing_tables.append(table)

    if missing_tables:
        logger.warning("❌ These tables do not exist:")
        for tbl in missing_tables:
            logger.warning(f" - {tbl}")
        logger.info("🚫 SQL will NOT be executed.")
    else:
        logger.info("✅ All tables exist. Executing SQL...")
        sp.sql(sql_script)
    # comment
    return df
