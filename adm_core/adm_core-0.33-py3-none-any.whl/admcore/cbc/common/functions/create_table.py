"""_summary_
"""
import os
from typing import Dict, List
from delta import DeltaTable
from dynaconf import Dynaconf
from loguru import logger
from pyspark.sql import DataFrame

import admcore.utils as ut


# pylint: disable="W0613"
def create_output_table(
        pl_conf: Dynaconf,
        output_table_conf
):
    """_summary_

    Args:
        pl_conf (Dynaconf): _description_
        output_table_conf (_type_): The output table config
    """

    runtime = os.environ['MFL_RUNTIME_ENV']

    sql = f"""
        CREATE {'EXTERNAL' if runtime=='local' else ''} TABLE IF NOT EXISTS {output_table_conf.name} (
            {','.join([k + ' ' + v for k, v in output_table_conf.schema.items()])}
        )
        USING DELTA
        {'LOCATION ' + "'" + os.environ['MFL_LOCAL_DELTA_TABLE_PATH'] + '/' + output_table_conf.name + "'" if runtime=='local' else ''};
    """

    ut.AdmSpark.get_spark_session().sql(sql)


def _parse_table_contract_constraints(
        constraints
) -> str:
    """_summary_

    Args:
        constraints (_type_): _description_

    Returns:
        str: _description_
    """
    if constraints:
        if 'not_null'in constraints and constraints.not_null is True:
            return 'NOT NULL'

    return ''


def _parse_column_comment(
        column_comment
) -> str:
    """_summary_

    Args:
        column_comment (_type_): _description_

    Returns:
        str: _description_
    """
    if column_comment and len(column_comment.strip()) > 0:
        return f"COMMENT '{column_comment}'"
    return ''

def _parse_partitioned_by(
        contract
) -> str:
    """_summary_

    Args:
        table_conf (_type_): _description_

    Returns:
        str: _description_
    """
    if ('performance' in contract and
        contract.performance is not None and
        'partitioned_by' in contract.performance and 
        'column_names' in contract.performance.partitioned_by and
        contract.performance.partitioned_by.column_names is not None):
        if isinstance(contract.performance.partitioned_by.column_names, list):
            if len(contract.performance.partitioned_by.column_names) > 0:
                sql_clause = f" PARTITIONED BY ({','.join(contract.performance.partitioned_by.column_names)})"
                return sql_clause
        else:
            raise ut.AdmError("ADM config format error: contract.performance.partitioned_by.column_names must be list")
    return ''

def _parse_cluster_by(
        contract
) -> str:
    """_summary_

    Args:
        table_conf (_type_): _description_

    Returns:
        str: _description_
    """
    if ('performance' in contract and
        contract.performance is not None and
        'cluster_by' in contract.performance and 
        'column_names' in contract.performance.cluster_by and
        contract.performance.cluster_by.column_names is not None):
        if isinstance(contract.performance.cluster_by.column_names, list):
            if len(contract.performance.cluster_by.column_names) > 0:
                sql_clause = f" CLUSTER BY ({','.join(contract.performance.cluster_by.column_names)})"
                return sql_clause
        else:
            raise ut.AdmError("ADM config format error: contract.performance.cluster_by.column_names must be list")
    return ''

def _parse_clustered_by_clause(
        contract
) -> str:
    """_summary_

    Args:
        table_conf (_type_): _description_

    Returns:
        str: _description_
    """
    if ('performance' in contract and
        contract.performance is not None and
        'clustered_by_clause' in contract.performance and
        'clustered_by_columns' in contract.performance.clustered_by_clause and
        contract.performance.clustered_by_clause.clustered_by_columns is not None):
        if isinstance(contract.performance.clustered_by_clause.clustered_by_columns, list):
            clustered_by_columns_columns = contract.performance.clustered_by_clause.clustered_by_columns
            sorted_by_columns = contract.performance.clustered_by_clause.sorted_by_columns
            num_buckets = contract.performance.clustered_by_clause.num_buckets

            sorted_by_columns_clause = f" SORTED BY ({','.join([i.name + ' ' + i.sort for i in sorted_by_columns])})" if sorted_by_columns is not None else ''
            num_buckets_clause = f" INTO {num_buckets} BUCKETS " if num_buckets is not None else ''

            sql_clause = f"CLUSTERED BY ({','.join(clustered_by_columns_columns)})" + \
                sorted_by_columns_clause + \
                num_buckets_clause
            
            return sql_clause
        else:
            raise ut.AdmError("ADM config format error: contract.performance.clustered_by_clause.clustered_by_columns must be list")
    return ''

# pylint: disable="W0102"
def create_table_by_contract(
        table_conf,
        pl_conf,
        extra_columns: List[Dict]=[]
) -> DeltaTable:
    """_summary_

    Args:
        table_conf (_type_): _description_
        pl_conf (_type_): _description_
        extra_columns (List[Dict]): _description_
    Returns:
        str: _description_
    """

    if isinstance(table_conf.contract, str) and (
        table_conf.contract.endswith('.yml') or table_conf.contract.endswith('.yaml')
    ):
        contract = ut.AdmConfig.load_config_file(
            config_file_path=table_conf.contract,
            session_variables=pl_conf.session_variables
        )
    else:
        contract = table_conf.contract

    # Merge extra columns to column definition 
    list_columns: List = contract.schema.columns.to_list()

    # DAIACM-4228
    list_columns[:0] = extra_columns

    contract.schema.columns = list_columns

    # Replace contract item with the loaded contract config
    table_conf.contract = contract

    runtime = os.environ['MFL_RUNTIME_ENV']

    sql = f"""
         CREATE {'EXTERNAL' if runtime=='local' else ''} TABLE IF NOT EXISTS {contract.table_name} (
            {','.join([i['name'] + ' ' + i['type'] + ' ' + 
                _parse_table_contract_constraints(i.get('constraints')) + ' ' +
                _parse_column_comment(i.get('description'))
                for i in contract.schema.columns])}
        )
        USING DELTA
        {_parse_partitioned_by(table_conf.contract) if runtime!='local' else ''}
        {_parse_cluster_by(table_conf.contract) if runtime!='local' else ''}
        {_parse_clustered_by_clause(table_conf.contract) if runtime!='local' else ''}
        {'LOCATION ' + "'" + os.environ['MFL_LOCAL_DELTA_TABLE_PATH'] + '/' + contract.table_name + "'" if runtime=='local' else ''}
        COMMENT '{contract.description}';
    """

    logger.debug(sql)

    ut.AdmSpark.get_spark_session().sql(sql)

    return ut.AdmSpark.get_delta_table(contract.table_name)

def create_table_by_contract_by_config(
        df,
        func_conf,
        action_conf,
        task_conf,
        pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    if ('system_columns' in func_conf.kwargs
        and func_conf.kwargs.system_columns is not None
        and isinstance(func_conf.kwargs.system_columns, list)):
        extra_columns = func_conf.kwargs.system_columns
    else:
        extra_columns=[]

    create_table_by_contract(
        table_conf=func_conf.kwargs,
        pl_conf=pl_conf,
        extra_columns=extra_columns
    )

    # Return df to make sure next function can get it
    return df
