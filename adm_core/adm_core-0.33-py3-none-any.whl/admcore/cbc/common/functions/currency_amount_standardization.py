"""_summary_
"""

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import FloatType


# pylint: disable="W0613"
def currency_amount_standardization(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """
    currency_code_column = func_conf.kwargs.options.get("currency_code_column", "currency_code")

    for col in func_conf.kwargs.columns:
        df = df.withColumn(
            col,
            F.when(
                F.col(col).rlike(
                    r"^[0-9.,]+$"
                ),  # Only keep numbers and periods, commas as thousand separators
                F.regexp_replace(F.col(col), r"[^0-9.]", "").cast(FloatType()),
            ).otherwise(
                F.lit(None)
            ),  # Set invalid values to null
        )

    return df
