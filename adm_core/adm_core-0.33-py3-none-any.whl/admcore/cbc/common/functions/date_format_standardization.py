"""_summary_
"""

from pyspark.sql import DataFrame, functions as F


# pylint: disable="W0613"
def date_format_standardization(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """

    output_format = func_conf.kwargs.options.get("format", "yyyy-MM-dd")

    # List of potential input date formats to try
    # List of potential input date formats to try
    input_formats = [
        "MM/dd/yyyy HH:mm:ss.SSSSSS",
        "MM/dd/yyyy HH:mm:ss",
        "MM/dd/yyyy",
        "yyyy-MM-dd HH:mm:ss.SSSSSS",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd",
        "dd-MM-yyyy HH:mm:ss.SSSSSS",
        "dd-MM-yyyy HH:mm:ss",
        "dd-MM-yyyy",
        "yyyy/MM/dd HH:mm:ss.SSSSSS",
        "yyyy/MM/dd HH:mm:ss",
        "yyyy/MM/dd",
        "dd/MM/yyyy HH:mm:ss.SSSSSS",
        "dd/MM/yyyy HH:mm:ss",
        "dd/MM/yyyy",
        "yyyy.MM.dd HH:mm:ss.SSSSSS",
        "yyyy.MM.dd HH:mm:ss",
        "yyyy.MM.dd",
        "dd.MM.yyyy HH:mm:ss.SSSSSS",
        "dd.MM.yyyy HH:mm:ss",
        "dd.MM.yyyy",
        "yyyyMMdd",
        "ddMMyyyy",
        "MMddyyyy",
        "yyyy-MM-dd'T'HH:mm:ss.SSSSSS",
        "yyyy-MM-dd'T'HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss'Z'",
        "yyyy/MM/dd'T'HH:mm:ss.SSSSSS",
        "yyyy/MM/dd'T'HH:mm:ss",
        "yyyy/MM/dd'T'HH:mm:ss'Z'",
        "yyyy.MM.dd'T'HH:mm:ss.SSSSSS",
        "yyyy.MM.dd'T'HH:mm:ss",
        "yyyy.MM.dd'T'HH:mm:ss'Z'"
        # Add more formats as needed
    ]

    for col in func_conf.kwargs.columns:
        # Attempt to parse with different formats until one works
        for fmt in input_formats:
            df = df.withColumn(
                col,
                F.when(
                    F.to_date(
                        F.col(col), fmt
                    ).isNotNull(),  # Check if the format is correct
                    F.date_format(F.to_date(F.col(col), fmt), output_format),
                ).otherwise(
                    F.col(col)
                ),  # Leave it unchanged if it doesn't match
            )

        # Set invalid values (still not matching) to null
        df = df.withColumn(
            col,
            F.when(
                F.to_date(F.col(col), output_format).isNull(), F.lit(None)
            ).otherwise(F.col(col)),
        )

    return df
