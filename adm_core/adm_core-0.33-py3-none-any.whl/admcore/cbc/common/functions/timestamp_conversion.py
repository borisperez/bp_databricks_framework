"""_summary_
"""

from pyspark.sql import DataFrame


# pylint: disable="W0613"
def timestamp_conversion(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """

    return df
