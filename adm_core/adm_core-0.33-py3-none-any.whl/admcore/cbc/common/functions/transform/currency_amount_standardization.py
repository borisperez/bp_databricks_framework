"""_summary_
"""

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import FloatType

from admcore.cbc.common.functions import df_input_output_wrapper


# pylint: disable="W0613"
@df_input_output_wrapper
def currency_amount_standardization(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    currency_code_column = func_conf.kwargs.options.get("currency_code_column", "currency_code")

    for col in func_conf.kwargs.columns:
        df = df.withColumn(
            col,
            F.when(
                F.col(col).rlike(
                    r"^[0-9.,]+$"
                ),  # Only keep numbers and periods, commas as thousand separators
                F.regexp_replace(F.col(col), r"[^0-9.]", "").cast(FloatType()),
            ).otherwise(
                F.lit(None)
            ),  # Set invalid values to null
        )

    return df
