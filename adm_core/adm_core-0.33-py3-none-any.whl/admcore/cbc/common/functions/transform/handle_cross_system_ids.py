"""_summary_
"""

from pyspark.sql import DataFrame, functions as F

from admcore.cbc.common.functions import df_input_output_wrapper


# pylint: disable="W0613"
@df_input_output_wrapper
def handle_cross_system_ids(
    df: DataFrame,
    func_conf,
    action_conf=None,
    task_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        action_conf (_type_, optional): _description_. Defaults to None.
        task_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """

    primary_system = func_conf.kwargs.get("primary_system", "SAP")
    secondary_system = func_conf.kwargs.get("secondary_system", "Salesforce")
    sap_id_column = func_conf.kwargs.get("sap_id_column", "sap_customer_id")
    salesforce_id_column = func_conf.kwargs.get("salesforce_id_column", "sf_account_id")

    for col in func_conf.kwargs.columns:
        if sap_id_column in df.columns and salesforce_id_column in df.columns:
            df = df.withColumn(
                col,
                F.when(
                    F.col(sap_id_column).isNotNull(), F.col(sap_id_column)
                ).otherwise(F.col(salesforce_id_column)),
            )

    return df
