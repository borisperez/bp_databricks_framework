"""_summary_
"""

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import StringType

from admcore.cbc.common.functions import df_input_output_wrapper


# pylint: disable="W0613"
@df_input_output_wrapper
def handle_null_values(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        action_conf (_type_, optional): _description_. Defaults to None.
        task_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """

    numeric_placeholder = func_conf.kwargs.get("numeric_null_placeholder", 0)
    string_placeholder = func_conf.kwargs.get("string_null_placeholder", "")

    for col in func_conf.kwargs.columns:
        col_type = df.schema[col].dataType
        if isinstance(col_type, StringType):
            df = df.withColumn(
                col,
                F.when(F.col(col).isNull(), F.lit(string_placeholder)).otherwise(
                    F.col(col)
                ),
            )
        else:
            df = df.withColumn(
                col,
                F.when(F.col(col).isNull(), F.lit(numeric_placeholder)).otherwise(
                    F.col(col)
                ),
            )

    return df
