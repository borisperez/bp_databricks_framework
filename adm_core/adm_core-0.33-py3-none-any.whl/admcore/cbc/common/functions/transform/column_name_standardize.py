"""_summary_
"""

import re
from pyspark.sql import DataFrame

from admcore.cbc.common.functions import df_input_output_wrapper


# pylint: disable="W0613"
@df_input_output_wrapper
def column_name_standardize(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        pl_conf (Dynaconf): _description_
        table_conf (_type_): _description_
        func_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    if func_conf.enable and bool(func_conf.kwargs):
        if ('invalid_chars' in func_conf.kwargs
                and 'replace_with' in func_conf.kwargs
                and func_conf.kwargs.invalid_chars is not None
                and func_conf.kwargs.replace_with is not None):
            replace_with = func_conf.kwargs.replace_with
            invalid_chars = func_conf.kwargs.invalid_chars

            cleaned_columns = [
                c.translate({ord(i): replace_with for i in invalid_chars}) for c in df.columns
            ]
            df = df.toDF(*cleaned_columns)

        if 'camel_to_snake_case' in func_conf.kwargs and func_conf.kwargs.camel_to_snake_case is True:
            snake_case_columns = [
                re.sub(r'(?<!^)(?=[A-Z])', '_', c).lower() for c in df.columns
            ]
            df = df.toDF(*snake_case_columns)

    return df
