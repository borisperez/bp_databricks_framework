"""_summary_
"""
import re
from loguru import logger
from pyspark.sql import DataFrame
from pyspark.sql.types import (StructType, ArrayType)
import pyspark.sql.functions as F

from admcore.cbc.common.functions.common_functions import df_input_output_wrapper
import admcore.utils as ut


def get_complex_columns(
        df: DataFrame,
        complex_types: tuple

) -> dict:
    """_summary_

    Args:
        df (DataFrame): _description_
        complex_types (tuple): _description_

    Returns:
        dict: _description_
    """

    complex_columns = dict(
            [(field.name, field.dataType)
                for field in df.schema.fields if isinstance(field.dataType, complex_types)]
    )

    return complex_columns


def validate_func_conf(
        func_conf
):
    """_summary_

    Args:
        func_conf (_type_): _description_

    Returns:
        _type_: _description_
    """

    if "kwargs" not in func_conf:
        raise ut.AdmError(f"kwargs parameter is missing in Function {func_conf.name}")
    if "flatten_struct_column" not in func_conf.kwargs:
        raise ut.AdmError(f"flatten_struct_column parameter is missing in kwargs in Function {func_conf.name}")
    if "flatten_array_column" not in func_conf.kwargs:
        raise ut.AdmError(f"flatten_array_column parameter is missing in kwargs in Function {func_conf.name}")
    
    if isinstance(func_conf.kwargs.flatten_struct_column, bool) is False:
        raise ut.AdmError(f"flatten_struct_column parameter must be bool in kwargs in Function {func_conf.name}")
    if isinstance(func_conf.kwargs.flatten_array_column, bool) is False:
        raise ut.AdmError(f"flatten_array_column parameter must be bool in kwargs in Function {func_conf.name}")


def replace_special_chars_regex(text):
    """_summary_

    Args:
        text (_type_): _description_

    Returns:
        _type_: _description_
    """

    pattern = r"[',;{}\[\]()\n\t= .]"
    return re.sub(pattern, "_", text)


# pylint: disable="W0613"
@df_input_output_wrapper
def flatten_complex_columns(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    validate_func_conf(func_conf)

    field_types = []
    if func_conf.kwargs.flatten_struct_column:
        field_types.append(StructType)
    if func_conf.kwargs.flatten_array_column:
        field_types.append(ArrayType)

    complex_fields = get_complex_columns(df, tuple(field_types))

    while len(complex_fields) != 0:
        col_name=list(complex_fields.keys())[0]
        logger.info("Processing: "+col_name+" Type: "+str(type(complex_fields[col_name])))

        if func_conf.kwargs.flatten_struct_column and isinstance(complex_fields[col_name], StructType):
            expanded = (
                [F.col(f"`{col_name}`.`{k}`").alias(col_name+'_' + replace_special_chars_regex(k))
                 for k in [ n.name for n in complex_fields[col_name]]]
            )

            df=df.select("*", *expanded).drop(col_name)
        elif func_conf.kwargs.flatten_array_column and isinstance(complex_fields[col_name], ArrayType):
            df=df.withColumn(col_name, F.explode_outer(col_name))
  
        complex_fields = get_complex_columns(df, tuple(field_types))

    return df
