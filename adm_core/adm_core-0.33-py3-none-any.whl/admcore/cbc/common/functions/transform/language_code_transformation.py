"""_summary_
"""

from pyspark.sql import DataFrame, functions as F

from admcore.cbc.common.functions import df_input_output_wrapper


# pylint: disable="W0613"
@df_input_output_wrapper
def language_code_transformation(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """
    codes_to_iso = func_conf.kwargs.options.get("codes_to_iso", {})

    for col in func_conf.kwargs.columns:
        if col in df.columns:
            # Build the CASE WHEN SQL expression
            cases = " ".join(
                [f"WHEN '{k}' THEN '{v}'" for k, v in codes_to_iso.items()]
            )
            case_expr = f"CASE {col} {cases} ELSE {col} END"

            # Apply the transformation
            df = df.withColumn(col, F.expr(case_expr))

    return df
