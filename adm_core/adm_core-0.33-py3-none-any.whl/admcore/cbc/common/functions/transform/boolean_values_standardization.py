"""_summary_
"""

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import StringType, BooleanType

from admcore.cbc.common.functions import df_input_output_wrapper


# pylint: disable="W0613"
@df_input_output_wrapper
def boolean_values_standardization(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """kwargs format:
    kwargs:
      input_function_name: str
      output_view_name: str
      columns: list
      options:
        true_values: list
        false_values: list

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    #df = adm_func.get_df_from_input_function(df, func_conf, action_conf)

    true_values = func_conf.kwargs.options.get("true_values", ["1", "y", "yes"])
    false_values = func_conf.kwargs.options.get("false_values", ["0", "n", "x"])

    for col in func_conf.kwargs.columns:
        df = df.withColumn(col, F.col(col).cast(StringType()))
        df = df.withColumn(
            col,
            F.when(F.col(col).isin(true_values), F.lit(True))
            .when(F.col(col).isin(false_values), F.lit(False))
            .otherwise(
                F.lit(None).cast(BooleanType())
            ),  # Handle malformed data by setting to None
        )

    #output_view_name = adm_func.get_output_view_name_in_function(func_conf)
    #if output_view_name:
    #    df.createOrReplaceGlobalTempView(name=output_view_name)

    return df
