"""_summary_
"""

import admcore.utils as ut


# pylint: disable="W0613"
def run_sql_scripts(
        func_name: str,
        func_conf,
        act_conf,
        pl_conf
):
    """This function can be used as a step in an action that needs to run a list of SQLs.

    Args:
        func_name (str): _description_
        func_conf (_type_): _description_
        act_conf (_type_): _description_
        pl_conf (_type_): _description_

    Raises:
        ut.AdmError: _description_
    """

    if ('enable' not in func_conf or 'sql_list' not in func_conf):
        raise ut.AdmError('Invalid SQL config!')

    if func_conf.enable:
        print(f'{func_name} started...')

        sp = ut.AdmSpark.get_spark_session()

        for sql in func_conf.sql_list:
            print(f'{sql.name} started...')
            if sql.sql.endswith(".yml"):
                # SQL script in another file
                sp.sql(ut.AdmConfig.load_config_file(sql.sql, pl_conf.session_variables).sql)
            else:
                # Embedded SQL script
                sp.sql(sql.sql)
            print(f'{sql.name} finished...')

        print(f'{func_name} finished.')
    else:
        print(f"{func_name} is disabled.")
