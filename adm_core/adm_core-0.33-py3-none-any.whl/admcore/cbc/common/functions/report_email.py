"""_summary_
"""

from loguru import logger

from datetime import datetime
import pyspark.sql.functions as F

import admcore.utils as ut


def run_report_sql_list(func_conf, pl_conf) -> list[dict]:
    """_summary_

    Args:
        act_conf (dict | Any): _description_
        pl_conf (Dynaconf): _description_

    Raises:
        ut.AdmError: _description_

    Returns:
        list[dict]: _description_
    """
    sp = ut.AdmSpark.get_spark_session()

    reports = []

    for sql in func_conf.kwargs.sql_list:
        logger.info(f'report SQL {sql.name} started...')

        if 'name' not in sql or 'sql' not in sql:
            raise ut.AdmError('Report task config file format error!')

        if sql.sql.endswith(".yml"):
            # SQL script in another file
            df = sp.sql(ut.AdmConfig.load_config_file(sql.sql, pl_conf.session_variables).sql)
        else:
            # Embedded SQL script
            df = sp.sql(sql.sql)

        # Convert all columns to string for unpivot
        for column in df.columns:
            df = df.withColumn(column, F.col(column).cast('string'))

        # Un-pivot the DF to make key-value pair DF
        df = df.unpivot(
            ids=[],
            values=df.columns,
            variableColumnName='key',
            valueColumnName='value'
        )

        report = {
            'name': sql.name,
            'data': df.toPandas().values.tolist()
        }

        reports.append(report)

        logger.info(f'report SQL {sql.name} finished...')

    return reports


# pylint: disable="W0613"
def send_report_unpivot(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
):
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_
    """

    # Validate if there is enough items in the YAML config file
    if ('email_notification' not in pl_conf or
        'report_name' not in pl_conf.email_notification or
        'recipients' not in pl_conf.email_notification):
        raise ut.AdmError("email_notification config error!")

    if ('kwargs' not in func_conf or
        'sql_list' not in func_conf.kwargs or
        len(func_conf.kwargs.sql_list) < 1):
        raise ut.AdmError('Report task config file format error!')

    reports = run_report_sql_list(func_conf, pl_conf)

    # Add execution time to df
    start_time = datetime.strptime(pl_conf.session_variables.batch_id, '%Y-%m-%d-%H-%M-%S-%f')
    end_time = datetime.now()
    execution_time = f"({(end_time - start_time).total_seconds()} seconds) + (possible 5 minutes Databricks starting time)"

    reports.append({
        "name": "performance",
        "data": [('execution_time', execution_time)]
    })

    # put everything to an HTML email body
    email_body = ' '.join([
        '<b>' + report['name'] + '</b>' + '<ul>' +
        ' '.join(['  <li>' + item[0] + ': ' + item[1] + '</li>' for item in report['data']]) +
        '</ul>'
        for report in reports
    ])

    email_body = f"Pipeline {pl_conf.info.enterprise_id} is done. Please don't reply this email. Please check the pipeline report as below." + "<br><br>" + email_body

    subject = f"no-reply: ADM pipeline {pl_conf.info.enterprise_id} is done"

    ut.AdmEmail(
        recipients=pl_conf.email_notification.recipients,
        subject=subject,
        body=email_body
    ).send_by_logic_app()
