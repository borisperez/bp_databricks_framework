"""_summary_
"""


# pylint: disable="W0613"

import os

from pyspark.sql import DataFrame

from admcore.cbc.common.functions.common_functions import df_input_output_wrapper


@df_input_output_wrapper
def print_df_simple(
    df: DataFrame,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    logging_level = os.getenv("MFL_LOGGING_LEVEL")
    if logging_level and logging_level.upper() == 'DEBUG':
        if func_conf.kwargs.print_df:
            df.show(n=20, truncate=False)
        if func_conf.kwargs.print_schema:
            df.printSchema()

    return df
