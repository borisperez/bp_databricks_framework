"""_summary_
"""

from pyspark.sql import (
    DataFrame,
    functions as F
)


# pylint: disable="W0613"
def add_constant_columns(
    df: DataFrame,
    func_conf,
    table_conf=None,
    act_conf=None,
    pl_conf=None
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_, optional): _description_. Defaults to None.
        act_conf (_type_, optional): _description_. Defaults to None.
        pl_conf (_type_, optional): _description_. Defaults to None.

    Returns:
        DataFrame: _description_
    """
    if func_conf.enable and bool(func_conf.kwargs):
        df.withColumns(
            dict(map(lambda kv: (kv[0], F.lit(kv[1])), func_conf.kwargs.items()))
        )

    return df
