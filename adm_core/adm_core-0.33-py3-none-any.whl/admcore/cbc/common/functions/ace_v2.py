"""_summary_
"""

from typing import Dict, List

from loguru import logger

from delta import DeltaTable
from pyspark.sql import DataFrame
import pyspark.sql.functions as F
from pyspark.sql.types import StructType

import  admcore.utils as ut
import admcore.cbc.common.functions as cbc_func


def _get_extra_columns_from_scd_links(
        links
) -> List[Dict]:
    """_summary_

    Args:
        links (_type_): _description_

    Returns:
        List[Dict]: _description_
    """

    if links and len(links) > 0:
        extra_columns = [
            {
                "name": x.lnk_cbc + "_hashkey",
                "type": "string", 
                "description": None, 
                "constraints": None
            } for x in links if x.key_columns and x.salt and x.lnk_cbc
        ]

        return extra_columns

    return []


def _create_table_scd2(
        hashkey_column_name,
        table_conf,
        pl_conf
) -> DeltaTable:
    """_summary_

    Args:
        hashkey_column_name (bool): _description_
        table_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DeltaTable: _description_
    """

    extra_columns = [
        {
            "name": hashkey_column_name,
            "type": "string",
            "description": "",
            "constraints": ""
        },
        {
            "name": "hash_diff",
            "type": "string",
            "description": "",
            "constraints": ""
        },
        {
            "name": "__start__",
            "type": "TIMESTAMP",
            "description": "",
            "constraints": ""
        },
        {
            "name": "__end__",
            "type": "TIMESTAMP",
            "description": "",
            "constraints": ""
        }
    ]

    if 'links' in table_conf:
        extra_columns.extend(_get_extra_columns_from_scd_links(table_conf.links))

    table = cbc_func.create_table_by_contract(
        table_conf=table_conf,
        pl_conf=pl_conf,
        extra_columns=extra_columns
    )

    return table


def _create_table_scd1(
        hashkey_column_name,
        table_conf,
        pl_conf
) -> DeltaTable:
    """_summary_

    Args:
        hashkey_column_name (bool): _description_
        table_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DeltaTable: _description_
    """

    extra_columns = [
        {
            "name": hashkey_column_name,
            "type": "string",
            "description": "",
            "constraints": ""
        },
        {
            "name": "hash_diff",
            "type": "string",
            "description": "",
            "constraints": ""
        }
    ]

    if 'links' in table_conf and table_conf.links is not None:
        extra_columns.extend(_get_extra_columns_from_scd_links(table_conf.links))

    table = cbc_func.create_table_by_contract(
        table_conf=table_conf,
        pl_conf=pl_conf,
        extra_columns=extra_columns
    )

    return table


def save_mode_scd2(df: DataFrame, hashkey_column_name: str, func_conf, pl_conf):
    """_summary_

    Args:
        df (_type_): _description_
        hashkey_column_name (_type_): _description_
        func_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    df_final = (
        df.withColumn("__start__", F.current_timestamp())
            .withColumn("__end__", F.lit(None).cast("timestamp"))
    )

    delta_table = _create_table_scd2(
        hashkey_column_name=hashkey_column_name,
        table_conf=func_conf.kwargs,
        pl_conf=pl_conf
    )

    # Try to make source data type lines up with target table
    table_schema: StructType = (
        ut.AdmSpark.get_spark_session().table(func_conf.kwargs.contract.table_name).schema
    )
    df_final = df_final.to(table_schema)

    # Perform a merge operation to handle SCD Type 2 changes
    logger.info("Performing merge operation for SCD Type 2")
    sp = ut.AdmSpark.get_spark_session()

    df_target_1 = sp.sql(f"""select {hashkey_column_name}, hash_diff
                          from {func_conf.kwargs.contract.table_name}
                          where __end__ is NULL
                          group by {hashkey_column_name}, hash_diff""")

    # Filter out all existing records in target from source
    df_source = (
        df_final
            .join(df_target_1, on=[hashkey_column_name, 'hash_diff'], how='left_anti')
            .select(df_final["*"])
    )

    delta_table.alias("target").merge(
        df_source.alias("source"),
            f"""target.{hashkey_column_name} = source.{hashkey_column_name}
            AND target.hash_diff != source.hash_diff 
            AND target.__end__ IS NULL"""
    ).whenMatchedUpdate(
        set={"__end__": "current_timestamp()"}
    ).whenNotMatchedInsertAll().execute()

    # Insert value-updated (with same cbc_hashkey) records in source to target table
    df_target_2 = sp.sql(f"""
                         select
                            {hashkey_column_name},
                            hash_diff
                         from
                            (
                                select 
                                    {hashkey_column_name},
                                    hash_diff,
                                    ROW_NUMBER() OVER (PARTITION BY __end__ ORDER BY __end__ desc) AS row_num
                                from {func_conf.kwargs.contract.table_name}
                                where __end__ is not NULL
                            ) AS subquery
                         where row_num=1
                         group by {hashkey_column_name}, hash_diff""")

    df_updated_value = df_source.join(
        df_target_2,
        (df_source[hashkey_column_name] == df_target_2[hashkey_column_name]) & (df_source.hash_diff != df_target_2.hash_diff),
        'inner'
    ).select(df_source["*"])

    if df_updated_value.isEmpty() is False:
        logger.info("Found updated values. These values will be inserted to target table using SCD2 logic.")
        ut.AdmSpark.df_to_table_append(df=df_updated_value, table_name=func_conf.kwargs.contract.table_name)


# pylint: disable="W0613"
def ace_v2(
    df,
    func_conf,
    action_conf,
    task_conf,
    pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (_type_): _description_
        func_conf (_type_): _description_
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_
        ut.AdmError: _description_
        ut.AdmError: _description_

    Returns:
        DataFrame: _description_
    """

    required_func_args = ["nat_keys", "salt", "save_mode"]
    for arg in required_func_args:
        if arg not in func_conf.kwargs:
            raise ut.AdmError("Missing required arguments in ACE function configuration: {arg}")

    cbc = func_conf.kwargs.cbc
    nat_keys = func_conf.kwargs.nat_keys
    salt = func_conf.kwargs.salt
    save_mode = func_conf.kwargs.save_mode
    links = func_conf.kwargs.links if 'links' in func_conf.kwargs else []

     # Validate that natKeys is a list of strings
    if not isinstance(nat_keys, list) or not all(isinstance(k, str) for k in nat_keys):
        raise ut.AdmError("nat_keys must be a list of strings.")

    salt_key = "|" + salt  # Prefix the salt with a pipe character
    hashkey_column_name = f"{cbc}_hashkey"

    # Get DataFrame from input function
    df = cbc_func.get_df_from_input_function(
        df=df,
        func_conf=func_conf,
        action_conf=action_conf
    )

    df_values = df.select([F.col(c) for c in df.columns if c not in nat_keys])

    # Generate HashDiff and CBC HashKey columns
    df_with_hash_diff = df.withColumn(
        "hash_diff", 
        F.sha2(
            F.concat_ws("|", *df_values.columns), 
            256
        )  # Hash of all selected columns
    ).withColumn(
        hashkey_column_name,
        F.sha2(
            F.concat(F.concat_ws("|", *[F.col(k) for k in nat_keys]), F.lit(salt_key)),
            256
        )  # Hash of natural keys with salt
    )

    # Process each link to generate additional hash keys
    for link in links:
        link_key_columns = link.key_columns
        link_key_constant = (
            link.key_constant
            if 'key_constant' in link and link.key_constant is not None
            else ''
        )
        link_salt = "|" + link.salt
        lnk_cbc = link.lnk_cbc.lower()
        link_hash_column_name = f"{lnk_cbc}_hashkey"

        # Validate that the required fields are present in each link
        if not link_key_columns or not link_salt or not lnk_cbc:
            raise ut.AdmError("Link configuration must include 'key_columns', 'salt', and 'lnk_cbc'.")

        # Generate the hash key for the link
        df_with_hash_diff = df_with_hash_diff.withColumn(
            link_hash_column_name,
            F.sha2(
                F.concat(F.concat_ws("|", *[F.col(k) for k in link_key_columns]), F.lit(link_key_constant), F.lit(link_salt)),
                256
            )
        )

    if save_mode == "scd2":
        save_mode_scd2(
            df=df_with_hash_diff,
            hashkey_column_name=hashkey_column_name,
            pl_conf=pl_conf,
            func_conf=func_conf
        )
    elif save_mode == "scd1":
        logger.info("Handling SCD Type 1 loading")
        # Try to load the Delta Table if it exists

        df_final = df_with_hash_diff

        delta_table = _create_table_scd1(
            hashkey_column_name=hashkey_column_name,
            table_conf=func_conf.kwargs,
            pl_conf=pl_conf
        )

        # Try to make source data type lines up with target table
        table_schema: StructType = ut.AdmSpark.get_spark_session().table(func_conf.kwargs.contract.table_name).schema
        df = df.to(table_schema)

        # Perform a merge operation to handle SCD Type 1 changes
        logger.info("Performing merge operation for SCD Type 1")
        delta_table.alias("target").merge(
            df_final.alias("source"),
            f"target.{cbc}_hashkey = source.{cbc}_hashkey"
        ).whenMatchedUpdateAll(
        ).whenNotMatchedInsertAll(
        ).execute()
    else:
        raise ut.AdmError("Invalid save_mode!")
