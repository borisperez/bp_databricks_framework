"""_summary_
"""

from soda.scan import Scan
import admcore.utils as ut


def data_quality_check_by_soda(
        act_conf,
        task_conf,
        pl_conf
):
    """_summary_

    Args:
        act_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
    """
    soda_config = ut.AdmConfig.load_config_file(
        act_conf.kwargs.soda_config_file_path,
        session_variables=None
    )

    for item in soda_config.to_dict():
        check_def = item.lower()
        if 'checks for' in check_def:
            view_name = check_def.split(' ')[-1]
            sp = ut.AdmSpark.get_spark_session()
            df = sp.sql(f"select * from {act_conf.kwargs.table_name}")
            df.createOrReplaceTempView(view_name)

            scan = Scan()
            if act_conf.kwargs.verbose:
                scan.set_verbose(True)
            scan.set_scan_definition_name(check_def)
            scan.set_data_source_name(view_name)

            scan.add_spark_session(sp, data_source_name=view_name)
            scan.add_sodacl_yaml_file(file_path=act_conf.kwargs.soda_config_file_path)

            scan.execute()

            # Could cause "Spark function is not whitelisted" error in some computes
            # sp.catalog.dropTempView(view_name)

            if len(scan.get_error_logs()) > 0:
                raise ut.AdmError(scan.get_error_logs_text())

            if len(scan.get_checks_fail()) > 0:
                raise ut.AdmError(scan.get_checks_fail_text())
