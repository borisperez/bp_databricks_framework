"""_summary_
"""


from typing import Any, Dict
from dynaconf import Dynaconf
from pyspark.sql import DataFrame, functions as F
import admcore.utils as ut
import admcore.cbc.common.functions as adm_func


# pylint: disable="W0613"
def load_csv(
    act_conf: Dict | Any,
    task_conf: Dict | Any,
    pl_conf: Dynaconf
):
    """

    Args:
        pl_conf (Dynaconf): _description_
        act_conf (_type_): _description_
    """

    batch_id = pl_conf.session_variables.batch_id
    file_type = act_conf.kwargs.raw_file.type
    file_path = act_conf.kwargs.raw_file.path_pattern
    spark_kwargs = act_conf.kwargs.raw_file.spark_kwargs
    write_mode = act_conf.kwargs.output_table.write_mode
    upsert_keys = (
        act_conf.kwargs.output_table.upsert_keys
            if 'upsert_keys' in act_conf.kwargs.output_table
            else None
    )

    if file_type in ['csv', 'tsv']:
        # Create table if it doesn't exist
        system_columns = [{
            'name': '_raw_file_name',
            'type': 'string',
            'description': 'The raw file name'
        }, {
            'name': '_batch_id',
            'type': 'string',
            'description': 'The batch_id for this data loading task'
        }]

        contract_config = ut.AdmConfig.load_config_file(
            config_file_path=act_conf.kwargs.output_table.contract,
            session_variables=pl_conf.session_variables
        )
        act_conf.kwargs.output_table.contract = contract_config

        adm_func.create_table_by_contract(
            pl_conf=pl_conf,
            table_conf=act_conf.kwargs.output_table,
            extra_columns=system_columns
        )

        sp = ut.AdmSpark.get_spark_session()

        df: DataFrame = sp.read.csv(
            path=file_path,
            **spark_kwargs
        )

        # Validate input file before adding extra columns and transformation
        if 'quality_check' in act_conf.kwargs:
            adm_func.data_quality_check_by_soda(
                df=df,
                func_conf=act_conf.kwargs.quality_check,
                act_conf=act_conf,
                task_conf=task_conf,
                pl_conf=pl_conf
            )

        df = ut.AdmSpark.replace_invalid_chars_in_col_names(df)

        df = df.withColumn("_raw_file_name", F.col("_metadata.file_name"))
        df = df.withColumn("_batch_id", F.lit(batch_id))

        table_name = act_conf.kwargs.output_table.contract.table_name
        adm_func.df_to_delta_table(
            df=df,
            table_name=table_name,
            mode=write_mode,
            upsert_keys=upsert_keys
        )

    else:
        raise ut.AdmError("Invalid raw file format")
