"""_summary_
"""


#pylint: disable=w0613
import importlib
from loguru import logger


def general_action(
        action_conf,
        task_conf,
        pl_conf
):
    """_summary_

    Args:
        action_conf (_type_): _description_
        task_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    return_data = None

    for func_conf in action_conf.functions:
        if func_conf.enable is True:
            logger.info(f"Function '{func_conf.name}' started")

            module_name = func_conf.module_file_path.split(':')[0]
            function_name = func_conf.module_file_path.split(':')[1]

            module = importlib.import_module(
                    module_name
            )
            function = getattr(module, function_name)

            return_data = function(return_data, func_conf, action_conf, task_conf, pl_conf)

            logger.info(f"Function '{func_conf.name}' finished")
        else:
            logger.info(f"Function '{func_conf.name}' disabled")
