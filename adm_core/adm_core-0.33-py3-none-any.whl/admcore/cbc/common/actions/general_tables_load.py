"""_summary_
"""
import importlib
from typing import Any, Dict
from dynaconf import Dynaconf
from pyspark.sql import DataFrame

import admcore.utils as ut
import admcore.cbc.common.functions as cbc_func


def run_preprocess_module(func_conf, act_conf, pl_conf):
    """_summary_

    Args:
        func_conf (_type_): _description_
        pl_conf (_type_): _description_
    """

    if ('name' not in func_conf or
        'enable' not in func_conf or
        'module_file_path' not in func_conf or
        'kwargs' not in func_conf):
        raise ut.AdmError('Invalid preprocess config!')

    if func_conf.enable:
        print(f'input_preprocess_module {func_conf.name} started...')

        module_name = func_conf.module_file_path.split(':')[0]
        function_name = func_conf.module_file_path.split(':')[1]

        module = importlib.import_module(module_name)
        function = getattr(module, function_name)

        function(func_conf, act_conf, pl_conf)

        print(f'Preprocess {func_conf.name} finished.')
    else:
        print('input_preprocess_module is disabled.')


# pylint: disable="W0613"
def run_preprocess_sql(func_conf, pl_conf):
    """_summary_

    Args:
        pl_conf (Dynaconf): _description_
        act_conf (_type_): _description_
    """

    if ('enable' not in func_conf or 'sql_list' not in func_conf):
        raise ut.AdmError('Invalid preprocess SQL config!')

    if func_conf.enable:
        print('Preprocess SQL started...')

        sp = ut.AdmSpark.get_spark_session()

        for sql in func_conf.sql_list:
            print(f'preprocess SQL {sql.name} started...')
            if sql.sql.endswith(".yml"):
                # SQL script in another file
                sp.sql(ut.AdmConfig.load_config_file(sql.sql, pl_conf.session_variables).sql)
            else:
                # Embedded SQL script
                sp.sql(sql.sql)
            print(f'preprocess SQL {sql.name} finished...')

        print('Preprocess SQL finished.')
    else:
        print("input_preprocess_sql is disabled.")


def apply_transform_function(
        df: DataFrame,
        func_conf,
        table_conf,
        act_conf,
        pl_conf
) -> DataFrame:
    """_summary_

    Args:
        df (DataFrame): _description_
        func_conf (_type_): _description_
        table_conf (_type_): _description_
        act_conf (_type_): _description_
        pl_conf (_type_): _description_

    Returns:
        DataFrame: _description_
    """

    if ('module_file_path' not in func_conf or
        'enable' not in func_conf or 
        'kwargs' not in func_conf):
        raise ut.AdmError('Invalid transform function config!')

    if func_conf.enable:
        print(f"Transform function {func_conf.module_file_path} started")

        module_name = func_conf.module_file_path.split(':')[0]
        function_name = func_conf.module_file_path.split(':')[1]

        module = importlib.import_module(module_name)
        function = getattr(module, function_name)

        result_df = function(
            df=df,
            func_conf=func_conf,
            table_conf=table_conf,
            act_conf=act_conf,
            pl_conf=pl_conf
        )

        print(f"Transform function {func_conf.module_file_path} finished")

        return result_df
    else:
        print(f"Function {func_conf.module_file_path} is disabled.")
        return df


# pylint: disable="W0613"
def load_delta_table(
    act_conf: Dict | Any,
    task_conf: Dict | Any,
    pl_conf: Dynaconf
):
    """_summary_

    Args:
        pl_conf (Dynaconf): _description_
        act_conf (_type_): _description_
    """

    # Run preprocess module if it exists
    if 'input_preprocess_module' in act_conf.kwargs:
        run_preprocess_module(act_conf.kwargs.input_preprocess_module, act_conf, pl_conf)

    # Run preprocess SQL if it exists
    if 'input_preprocess_sql' in act_conf.kwargs:
        #run_preprocess_sql(act_conf.kwargs.input_preprocess_sql, pl_conf)
        cbc_func.run_sql_scripts(
            func_name='input_preprocess_sql',
            func_conf=act_conf.kwargs.input_preprocess_sql,
            act_conf=act_conf,
            pl_conf=pl_conf
        )

    if 'output_tables' in act_conf.kwargs:
        for output_table in act_conf.kwargs.output_tables:
            # Load input temp view
            sql = f"SELECT * FROM {output_table.input_table}"
            df = ut.AdmSpark.get_spark_session().sql(sql)

            for cbc_func_conf in output_table.transform_functions:
                df = apply_transform_function(
                    df=df,
                    func_conf=cbc_func_conf,
                    table_conf=output_table,
                    act_conf=act_conf,
                    pl_conf=pl_conf
                )

            # Only select columns defined in schema
            columns_to_select = [kv[0] for kv in output_table.schema.items()]
            df = df.select(*columns_to_select)

            # Create output table if it doesn't exist
            cbc_func.create_output_table(pl_conf, output_table)

            # to-do: Save final DF to the output table
            cbc_func.df_to_delta_table(
                df=df,
                table_name=output_table.name,
                mode=output_table.write_mode.mode,
                upsert_keys=output_table.write_mode.upsert_keys
            )

    # Postprocess if the config exists
    if "postprocess_sql" in act_conf.kwargs:
        cbc_func.run_sql_scripts(
            func_name="postprocess_sql",
            func_conf=act_conf.kwargs.postprocess_sql,
            act_conf=act_conf,
            pl_conf=pl_conf
        )


# pylint: disable="W0613"
def load_delta_table_by_policy(
    act_conf: Dict | Any,
    task_conf: Dict | Any,
    pl_conf: Dynaconf
):
    """_summary_

    Args:
        pl_conf (Dynaconf): _description_
        act_conf (_type_): _description_
    """

    # Run preprocess module if it exists
    if 'input_preprocess_module' in act_conf.kwargs:
        run_preprocess_module(act_conf.kwargs.input_preprocess_module, act_conf, pl_conf)

    # Run preprocess SQL if it exists
    if 'input_preprocess_sql' in act_conf.kwargs:
        #run_preprocess_sql(act_conf.kwargs.input_preprocess_sql, pl_conf)
        cbc_func.run_sql_scripts(
            func_name='input_preprocess_sql',
            func_conf=act_conf.kwargs.input_preprocess_sql,
            act_conf=act_conf,
            pl_conf=pl_conf
        )

    if 'output_tables' in act_conf.kwargs:
        for output_table in act_conf.kwargs.output_tables:
            # Load input temp view
            sql = f"SELECT * FROM {output_table.input_table}"
            df = ut.AdmSpark.get_spark_session().sql(sql)

            if 'transform_functions' in output_table:
                for cbc_func_conf in output_table.transform_functions:
                    df = apply_transform_function(
                        df=df,
                        func_conf=cbc_func_conf,
                        table_conf=output_table,
                        act_conf=act_conf,
                        pl_conf=pl_conf
                    )

            # This function only supports table schema defined in contract file so far
            contract = ut.AdmConfig.load_config_file(
                config_file_path=output_table.contract,
                session_variables=pl_conf.session_variables
            )

            # Replace contract item with the loaded contract config
            output_table.contract = contract

            # Only select columns defined in contract schema
            columns_to_select = [d.name for d in output_table.contract.schema.columns]
            df = df.select(*columns_to_select)

            # Save final DF to the output table by policy defined in save_policy config item
            if 'save_policy' not in output_table:
                raise ut.AdmError("save_policy is missing in config file")

            output_table.save_policy['enable'] = True

            apply_transform_function(
                df=df,
                func_conf=output_table.save_policy,
                table_conf=output_table,
                act_conf=act_conf,
                pl_conf=pl_conf
            )

    # Postprocess if the config exists
    if "postprocess_sql" in act_conf.kwargs:
        cbc_func.run_sql_scripts(
            func_name="postprocess_sql",
            func_conf=act_conf.kwargs.postprocess_sql,
            act_conf=act_conf,
            pl_conf=pl_conf
        )
