"""_summary_
"""

from datetime import datetime
import os
from typing import Any, Dict
from dynaconf import Dynaconf
import pandas as pd
from pyspark.sql.types import StructType
import pyspark.sql.functions as F
import admcore.utils as ut
import admcore.cbc.common.functions as adm_func


# pylint: disable="W0613"
def load_excel_by_timestamp(
    act_conf: Dict | Any,
    task_conf: Dict | Any,
    pl_conf: Dynaconf
):
    """_summary_

    Args:
        act_conf (Dict | Any): _description_
        task_conf (Dict | Any): _description_
        pl_conf (Dynaconf): _description_

    Raises:
        ut.AdmError: _description_
        ut.AdmError: _description_
    """

    batch_id = pl_conf.session_variables.batch_id
    file_type = act_conf.kwargs.raw_file.type
    file_path = act_conf.kwargs.raw_file.path_pattern
    pandas_kwargs = act_conf.kwargs.raw_file.pandas_kwargs
    table_name = act_conf.kwargs.output_table.name
    write_mode = act_conf.kwargs.output_table.write_mode
    upsert_keys = (
        act_conf.kwargs.output_table.upsert_keys
            if 'upsert_keys' in act_conf.kwargs.output_table
            else None
    )

    if file_type == 'excel':
        act_conf.kwargs.output_table.schema['_raw_file_name'] = 'string'
        act_conf.kwargs.output_table.schema['_sheet_name'] = 'string'
        act_conf.kwargs.output_table.schema['_upload_time'] = 'timestamp'
        act_conf.kwargs.output_table.schema['_batch_id'] = 'string'

        sdf_all = ut.AdmSpark.get_spark_session().createDataFrame([], StructType([]))

        for file_name in os.listdir(file_path):
            file_path = os.path.join(file_path, file_name)
            if os.path.isfile(file_path) and file_name.endswith(('.xlsx', '.xls', '.xlsm')):
                # Make sure converting all columns to str safely
                if 'dtype' not in pandas_kwargs:
                    pandas_kwargs['dtype'] = 'object'
                df = (
                    pd.read_excel(file_path, **pandas_kwargs)
                        .astype(str)
                        .apply(lambda x: x.str.strip())
                )

                sdf = ut.AdmSpark.get_spark_session().createDataFrame(df)

                adm_func.data_contract_validation(
                    df=sdf,
                    func_conf=act_conf.kwargs.quality_check,
                    pl_conf=pl_conf
                )

                timestamp = os.path.getmtime(file_path)
                last_modified = datetime.fromtimestamp(timestamp)
                sdf = sdf.withColumn("_upload_time", F.lit(last_modified))

                sdf = sdf.withColumn("_raw_file_name", F.lit(file_name))
                sdf = sdf.withColumn("_batch_id", F.lit(batch_id))

                excel_file = pd.ExcelFile(file_path)
                sheet_names = excel_file.sheet_names
                sdf = sdf.withColumn("_sheet_name", F.lit(sheet_names[pandas_kwargs['sheet_name']]))

                if sdf_all.isEmpty():
                    sdf_all = sdf
                else:
                    sdf_all = sdf_all.union(sdf)
            else:
                raise ut.AdmError("Invalid raw file format")

        if sdf.isEmpty() is False:
            adm_func.df_to_delta_table(
                df=sdf,
                table_name=table_name,
                mode=write_mode,
                upsert_keys=upsert_keys
            )
    else:
        raise ut.AdmError("Invalid raw file format")
