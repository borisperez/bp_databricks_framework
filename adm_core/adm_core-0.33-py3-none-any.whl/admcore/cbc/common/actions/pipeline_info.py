"""This module loads tps data provider info to table dim.tps_provider 
using config items in before task config file. Note: This module only
works for pyspark>=3.3
"""

import hashlib
from typing import Dict, Any

from dynaconf import Dynaconf
from pyspark.sql import DataFrame
import admcore.utils as ut


# pylint: disable="W0613"
def load_pipeline_info_table(
    act_conf: Dict | Any,
    task_conf: Dict | Any,
    pl_conf: Dynaconf
):
    """_summary_

    Args:
        act_conf (Dict | Any): _description_
        task_conf (Dict | Any): _description_
        pl_conf (Dynaconf): _description_

    Raises:
        ut.AdmError: _description_
    """

    sp = ut.AdmSpark.get_spark_session()

    table_name = act_conf.kwargs.table_name
    columns: dict = act_conf.kwargs.columns
    pmk_column_name: str = act_conf.kwargs.pmk_column.name
    pmk_column_type: str = act_conf.kwargs.pmk_column.data_type
    pmk_column_value: str = act_conf.kwargs.columns[pmk_column_name]

    check_sum_values = [str(kv[1]) for kv in columns.items()]
    check_sum_values.sort()

    check_sum = hashlib.md5(
        "-".join(check_sum_values).encode('utf-8')
    ).hexdigest()

    if pmk_column_type == 'int':
        df: DataFrame = sp.sql(
            f"SELECT _check_sum FROM {table_name} WHERE {pmk_column_name}={pmk_column_value}"
        )
    elif pmk_column_type == 'string':
        df: DataFrame = sp.sql(
            f"SELECT _check_sum FROM {table_name} WHERE {pmk_column_name}='{pmk_column_value}'"
        )
    else:
        raise ut.AdmError("Invalid pmk data type. It only supports string or int")

    if df.isEmpty() or df.first()['_check_sum'] != check_sum:
        columns['_check_sum'] = check_sum
        df_new = ut.AdmSpark.create_dataframe_from_dict(columns)
        ut.AdmSpark.df_to_table_upsert(df_new, [pmk_column_name], table_name)
        print(f"Finished Updating table {table_name}")
    else:
        print(f"Skipped updating table {table_name}")
