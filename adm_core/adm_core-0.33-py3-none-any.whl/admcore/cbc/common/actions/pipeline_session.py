"""_summary_
"""


# pylint: disable="W0613"
from typing import Any, Dict

from dynaconf import Dynaconf


def add_session_variables(
        act_conf: Dict | Any,
        task_conf: Dict | Any,
        pl_conf: Dynaconf
):
    """_summary_

    Args:
        act_conf (Dict | Any): _description_
        task_conf (Dict | Any): _description_
        pl_conf (Dynaconf): _description_
    """

    variables = act_conf.kwargs.variables
    for variable in variables:
        pl_conf.session_variables[variable] = variables[variable]
        task_conf.session_variables[variable] = variables[variable]
