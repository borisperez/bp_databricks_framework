"""security:
     row_level:
       enable: true
       column_name:
       entitlement_table:
       function_name:
"""

from loguru import logger
import admcore.utils as ut


def create_default_filter_function(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    rls = contract.security.row_level

    rls_col = next((col for col in contract.schema.columns if col.name == rls.column_name), None)
    if rls_col is None:
        raise ut.AdmError(f"{rls.column_name} doesn't exist in table {contract.table_name}")

    sql = f"""CREATE OR REPLACE FUNCTION {rls.function}({rls.column_name} {rls_col.type})
              RETURNS BOOLEAN
              RETURN (
                EXISTS(SELECT 1 FROM {rls.entitlement_table} WHERE user_name = current_user() and is_admin IS TRUE) OR
                ({rls.column_name} in (SELECT {rls.column_name} FROM {rls.entitlement_table} where user_name = current_user()))
              );"""
    ut.AdmSpark.get_spark_session().sql(sql)


def apply_filter_function(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    rls = contract.security.row_level

    sql = f"""ALTER TABLE {contract.table_name}
              SET ROW FILTER {rls.function} ON ({rls.column_name});"""

    ut.AdmSpark.get_spark_session().sql(sql)


def update_rls(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    sp = ut.AdmSpark.get_spark_session()

    if not sp.catalog.tableExists(contract.table_name):
        logger.warning(f"Table {contract.table_name} doesn't exist")
        return

    if contract.security.row_level.enable:
        create_default_filter_function(contract)
        apply_filter_function(contract)
