"""Create table based on data contract config files.
   Catch schema updates in data contract files and update the schema of existing table.
   Note: It supports the following schema update so far.
        Column update:
            1. Add new columns
            2. Column Constraints update
                2.1 Update DEFAULT
                2.2 Update NOT NULL
                2.3 Update comment
            3. Update tags

        Table update:
            1. Add/Update/Delete table comment
            2. Add/Update/Delete table tags
"""

from enum import Enum
import os
import re
from typing import Dict, List
import argparse

from loguru import logger
from deepdiff import DeepDiff
import pandas as pd

from admcore.tools.table_manager.cls.db_cls import update_cls
from admcore.tools.table_manager.db_crud import run_crud_operations
from admcore.tools.table_manager.db_permission import update_permission
from admcore.tools.table_manager.db_rls_v2 import update_rls
import admcore.tools.table_manager.file_diff as file_diff
import admcore.utils as ut


#pylint: disable=R0914
#pylint: disable=C0301
def get_table_schema_with_constraints(
        table_name: str
) -> Dict:
    """Fetch and parse table schema with constraints from SHOW CREATE TABLE output.
    Note: Table creating SQL has to match this pattern: 
    "CREATE TABLE persons(
        first_name STRING NOT NULL, 
        last_name STRING NOT NULL, 
        nickname STRING,
        CONSTRAINT persons_pk PRIMARY KEY(first_name, last_name)
    ) USING DELTA;"

    Args:
        table_name (_type_): _description_

    Returns:
        dict: []
    """

    sp = ut.AdmSpark.get_spark_session()

    df = sp.sql(f"SHOW CREATE TABLE {table_name}")
    create_table_sql = df.collect()[0][0]  # Extract SQL statement as string
    logger.debug(f"CREATE TABLE SQL: {create_table_sql}")

    # Ensure consistent formatting by removing newlines
    create_table_sql = create_table_sql.replace("\n", " ")

    # Extract only the column definitions inside the first pair of parentheses
    table_structure_match = re.search(r"\((.*?)\)\s+USING", create_table_sql, re.DOTALL | re.IGNORECASE)
    if not table_structure_match:
        logger.error("Could not extract table structure.")
        raise ut.AdmError(f"Could not extract table structure for {table_name}")

    table_structure = table_structure_match.group(1).strip()

    # Debugging: Print extracted table structure
    logger.debug("Extracted Table Structure: ", table_structure)

    # Initialize list to store schema
    schema = {"columns": []}

    # Split lines to correctly extract column definitions vs constraints
    lines = table_structure.split(",")

    column_pattern = re.compile(
        r"^\s*(\w+)\s+([\w()]+)"  # Column name and data type
        r"(?:\s+NOT NULL)?"  # Optional NOT NULL constraint
        r"(?:\s+DEFAULT\s+([^ ,]+))?"  # Optional DEFAULT constraint
        r"(?:\s+COMMENT\s+'([^']*)')?",  # Optional COMMENT constraint
        #r"(?:\s+PRIMARY KEY)?",  # Optional inline PRIMARY KEY constraint
        re.IGNORECASE
    )

    for line in lines:
        line = line.strip()

        # Skip table-level constraints
        if line.upper().startswith("CONSTRAINT") or line.upper().startswith("PRIMARY KEY"):
            continue

        # Match column definitions
        match = column_pattern.match(line)
        if match:
            column_name = match.group(1)  # Column name
            data_type = match.group(2)  # Data type
            not_null = "NOT NULL" in line  # Check if NOT NULL exists
            default_value = match.group(3)  # Extract default value if available
            comment = match.group(4) if match.group(4) else None  # Extract comment if available

            schema["columns"].extend([{
                "name": column_name,
                "type": data_type,
                "description": comment,
                "constraints": {
                    "primary_key": False, # Default is False, will update below if it's in primary key list
                    "not_null": not_null,
                    "default": default_value
                }
            }])

    # Extract table-level PRIMARY KEY
    primary_key_match = re.search(r"PRIMARY KEY\s*\((.*?)\)", table_structure, re.IGNORECASE)
    if primary_key_match:
        primary_keys = primary_key_match.group(1).replace("`", "").split(",")
        for pk in primary_keys:
            pk = pk.strip()
            item = next(i for i in schema["columns"] if i["name"] == pk)
            item["constraints"]["unique"] = True

    return schema


#pylint: disable=R0914
#pylint: disable=C0301
def get_column_schema_difference(
        table_name: str,
        contract_columns: list
) -> tuple:
    """_summary_

    Args:
        data_contract_file_path (str): _description_

    Returns:
        tuple: _description_
    """

    # Get column list from data contract file
    #contract = ut.AdmConfig.load_config_file(data_contract_file_path, session_variables=None)
    #contract_columns = contract.schema.columns

    # Get column list from table
    table_columns = get_table_schema_with_constraints(table_name)['columns']

    # Get new columns and deleting columns
    table_dict = {item['name']: item for item in table_columns}
    contract_dict = {item['name']: item for item in contract_columns}

    add_column_list = [contract_dict[k] for k in contract_dict if k not in table_dict]
    delete_column_list = [table_dict[k] for k in table_dict if k not in contract_dict]

    updated_column_list = {
        k: DeepDiff(contract_dict[k], table_dict[k], ignore_order=True).to_dict()
        for k in contract_dict if k in table_dict and contract_dict[k] != table_dict[k]
    }

    return (add_column_list, delete_column_list, updated_column_list)


def get_add_column_sql_list(
        table_name: str,
        diff_result: dict
) -> list[str]:
    """_summary_

    Args:
        table_name (str): _description_
        diff_result (dict): _description_

    Returns:
        list[str]: _description_
    """

    sql_list = []

    for k, v in diff_result.items():
        not_null = v['constraints']['not_null'] if v['constraints']['not_null'] else ''
        default = f"DEFAULT {v['constraints']['default']}" if v['constraints']['default'] else ''

        # TO-DO: New column as part of primary key. 
        sql = f"ALTER TABLE {table_name} ADD COLUMN {k} {v['type']} {not_null} {default}"

        sql_list.append(sql)

    return sql_list


def get_delete_column_sql_list(
        table_name: str,
        diff_result: dict
) -> list[str]:
    """_summary_

    Args:
        table_name (str): _description_
        diff_result (dict): _description_

    Returns:
        list[str]: _description_
    """

    sql_list = []

    for k, v in diff_result.items():
        # TO-DO: Deleting column is part of primary key.

        sql = f"ALTER TABLE {table_name} DROP COLUMN {k}"

        sql_list.append(sql)

    return sql_list


def get_update_column_sql_list(
        table_name: str,
        diff_result: dict
) -> list[str]:
    """_summary_

    Args:
        table_name (str): _description_
        diff_result (dict): _description_

    Returns:
        list[str]: _description_
    """

    # TO-DO: Primary key update

    sql_list = []

    for k, v in diff_result.items():
        values_changed = v['values_changed']
        for k1, v1 in values_changed.items():
            if 'description' in k1:
                sql_list.append(
                    f"""ALTER TABLE {table_name} ALTER COLUMN {k} COMMENT '{v1["new_value"]}'"""
                )
            if "['constraints']['not_null']" in k1:
                sql_list.append(
                    f"""ALTER TABLE {table_name} ALTER COLUMN {k} SET NOT NULL""" if v1["new_value"] else
                    f"""ALTER TABLE {table_name} ALTER COLUMN {k} DROP NOT NULL"""
                )

        type_changes = v['type_changes']
        for k1, v1 in type_changes.items():
            if "['constraints']['default']" in k1:
                sql_list.append(
                    f"""ALTER TABLE {table_name} ALTER COLUMN {k} SET DEFAULT {v1["new_value"]}""" if isinstance(v1["new_value"], str) else
                    f"""ALTER TABLE {table_name} ALTER COLUMN {k} DROP DEFAULT"""
                )


    return sql_list


def update_table_tags(
        sp,
        table_name: str,
        table_tags: list[dict]
):
    """_summary_

    Args:
        table_name (str): _description_
    """

    if not sp.catalog.tableExists(table_name):
        logger.warning(f"Table {table_name} doesn't exist")
        return

    names = table_name.split('.')

    df = sp.sql(f"""
        SELECT tag_name, tag_value FROM {names[0]}.information_schema.table_tags
        WHERE schema_name='{names[1]}' and table_name='{names[2]}'
    """)

    existing_tags = [row.asDict() for row in df.collect()]

    existing_tags_key = {item['tag_name']: item for item in existing_tags}
    table_tags_key = {item['name']: item for item in table_tags} if table_tags else {}
    delete_tags = [existing_tags_key[key] for key in existing_tags_key if key not in table_tags_key]

    # Delete tags in existing table
    if delete_tags and len(delete_tags) > 0:
        sql = f"""ALTER TABLE {table_name} UNSET TAGS({",".join(["'" + i["tag_name"] + "'" for i in delete_tags])})"""
        logger.info(f"SQL statement: {sql}")
        sp.sql(sql)

    # Add new tags and update all existing tags
    if table_tags and len(table_tags) > 0 and table_tags[0]['name'] and table_tags[0]['value']:
        tag_expression = ",".join(f"'{i['name']}'='{i['value']}'" for i in table_tags)
        sql = f"""ALTER TABLE {table_name} SET TAGS({tag_expression})"""
        logger.info(f"SQL statement: {sql}")
        sp.sql(sql)


def update_table_comment(
        sp,
        table_name,
        comment
):
    """_summary_

    Args:
        table_name (_type_): _description_
        comment (_type_): _description_
    """
    comment = comment if comment else ""
    sql = f"COMMENT ON TABLE {table_name} IS '{comment}'"
    logger.info(f"SQL statement: {sql}")
    sp.sql(sql)


def update_column_tags(
        sp,
        table_name: str,
        contract_columns: List[Dict]
):
    """_summary_

    Args:
        sp (_type_): _description_
        table_name (str): _description_
        contract_columns (list[dict]): _description_
    """

    if not sp.catalog.tableExists(table_name):
        logger.warning(f"Table {table_name} doesn't exist")
        return

    def add_tags_sql(g):
        tag_expression = ",".join("'" + g['tag_name'] + "'" + "=" + "'" + g['tag_value'] + "'")
        sql = f"ALTER TABLE {table_name} ALTER COLUMN {g.iloc[0]['column_name']} SET TAGS({tag_expression})"
        return sql

    def delete_tags_sql(g):
        tag_expression = ",".join("'" + g['tag_name'] + "'")
        sql = f"ALTER TABLE {table_name} ALTER COLUMN {g.iloc[0]['column_name']} UNSET TAGS({tag_expression})"
        return sql

    names = table_name.split(".")
    df_table = sp.sql(f"""
                SELECT column_name, tag_name, tag_value FROM {names[0]}.information_schema.column_tags
                WHERE schema_name='{names[1]}' and table_name='{names[2]}'
                """)
    pdf_table = df_table.toPandas()

    rows = []
    for item in contract_columns:
        column_name = item['name']
        if 'tags' in item and isinstance(item['tags'], list) and len(item['tags'])>0:
            for tag in item['tags']:
                rows.append({
                    'column_name': column_name,
                    'tag_name': tag['name'],
                    'tag_value': tag['value']
                })
    if len(rows) > 0:
        pdf_contract = pd.DataFrame(rows)
    else:
        pdf_contract = pd.DataFrame(columns=['column_name', 'tag_name', 'tag_value']).astype(str)

    pdf_diff = pdf_contract.merge(pdf_table, how='outer', indicator=True)

    pdf_delete_tags = pdf_diff[pdf_diff['_merge']=='right_only'].drop(columns=['_merge'])
    pdf_add_tags = pdf_diff[pdf_diff['_merge']=='left_only'].drop(columns=['_merge'])

    delete_tags = pdf_delete_tags.groupby('column_name', group_keys=False).apply(delete_tags_sql)
    add_tags = pdf_add_tags.groupby('column_name', group_keys=False).apply(add_tags_sql)

    if delete_tags.empty is False:
        for sql in list(delete_tags):
            logger.info(f"SQL statement: {sql}")
            sp.sql(sql)

    if add_tags.empty is False:
        for sql in list(add_tags):
            logger.info(f"SQL statement: {sql}")
            sp.sql(sql)


def update_column_comment(
        sp,
        table_name: str,
        contract_columns: List[Dict]
):
    """_summary_

    Args:
        sp (_type_): _description_
        table_name (str): _description_
        contract_columns (List[Dict]): _description_
    """
    if not sp.catalog.tableExists(table_name):
        logger.warning(f"Table {table_name} doesn't exist")
        return

    names = table_name.split(".")
    df_table = sp.sql(f"""
                SELECT column_name, comment FROM {names[0]}.information_schema.columns
                WHERE table_schema='{names[1]}' and table_name='{names[2]}'
                """)
    pdf_table = df_table.toPandas()

    rows = []
    for item in contract_columns:
        if 'description' in item and isinstance(item['description'], str) and item['description']:
            rows.append({'column_name': item['name'], 'comment': item['description']})
    if len(rows) > 0:
        pdf_contract = pd.DataFrame(rows)
    else:
        pdf_contract = pd.DataFrame(columns=['column_name', 'comment']).astype(str)

    pdf_diff = pdf_contract.merge(pdf_table, how='outer', indicator=True)

    pdf_delete = pdf_diff[pdf_diff['_merge']=='right_only'].drop(columns=['_merge'])
    pdf_add = pdf_diff[pdf_diff['_merge']=='left_only'].drop(columns=['_merge'])

    pdf_delete['sql'] = f"ALTER TABLE {table_name} ALTER COLUMN " + pdf_delete['column_name'] + " COMMENT ''"
    pdf_add['sql'] = f"ALTER TABLE {table_name} ALTER COLUMN " + pdf_add['column_name'] + " COMMENT '" + pdf_add['comment'] + "'"

    for sql in list(pdf_delete['sql']):
        logger.info(f"SQL statement: {sql}")
        sp.sql(sql)

    for sql in list(pdf_add['sql']):
        logger.info(f"SQL statement: {sql}")
        sp.sql(sql)


def update_table_schema_by_contract(
        data_contract_file_path: str
):
    """_summary_

    Args:
        data_contract_file_path (str): _description_
    """

    contract = ut.AdmConfig.load_config_file(data_contract_file_path, session_variables=None)
    contract_columns = contract.schema.columns

    add_column_list, delete_column_list, updated_column_list = get_column_schema_difference(
        contract.table_name,
        contract_columns
    )

    add_column_sql_list = get_add_column_sql_list(contract.table_name, add_column_list)
    del_column_sql_list = get_delete_column_sql_list(contract.table_name, delete_column_list)
    update_column_sql_list = get_update_column_sql_list(contract.table_name, updated_column_list)

    sp = ut.AdmSpark.get_spark_session()

    logger.info(f"Execute SQLs to add new columns to table {contract.table_name}")
    for sql in add_column_sql_list:
        logger.info(f"SQL statement: {sql}")
        sp.sql(sql)

    logger.info(f"Execute SQLs to delete columns from table {contract.table_name}")
    for sql in del_column_sql_list:
        logger.info(f"SQL statement: {sql}")
        sp.sql(sql)

    logger.info(f"Execute SQLs to update columns in table {contract.table_name}")
    for sql in update_column_sql_list:
        logger.info(f"SQL statement: {sql}")
        sp.sql(sql)


def update_comment_and_tags(
    contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    sp = ut.AdmSpark.get_spark_session()

    logger.info(f"Execute SQLs to update table comment for table {contract.table_name}")
    contract['description'] = contract.description if 'description' in contract else None
    update_table_comment(sp, contract.table_name, contract.description)

    logger.info(f"Execute SQLs to update table tags for table {contract.table_name}")
    contract['tags'] = contract.tags if 'tags' in contract else None
    update_table_tags(sp, contract.table_name, contract.tags)

    logger.info(f"Execute SQLs to update column commment for table {contract.table_name}")
    update_column_comment(sp, contract.table_name, contract.schema.columns)

    logger.info(f"Execute SQLs to update column tags for table {contract.table_name}")
    update_column_tags(sp, contract.table_name, contract.schema.columns)


def find_yaml_files(
        path
) -> list[str]:
    """_summary_

    Args:
        path (_type_): _description_

    Returns:
        list[str]: _description_
    """

    yaml_files = []
    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith(('.yaml', '.yml')):
                yaml_files.append(os.path.join(root, file))
    return yaml_files

class AdmSchemaFileType(Enum):
    """_summary_

    Args:
        Enum (_type_): _description_
    """
    CONTRACT = "data_contract"
    CRUD = "data_crud"

def process_contract_files(
        project_root_path: str,
        contract_file_path_list: list[str],
        git_repo_name: str=None,
        checksum_table_name: str=None
):
    """_summary_

    Args:
        project_root_path (str): _description_
        contract_file_path_list (list[str]): _description_
        git_repo_name (str, optional): _description_. Defaults to None.
    """
    for contract_file_path in contract_file_path_list:
        contract_file_paths = find_yaml_files(os.path.join(project_root_path, contract_file_path))

        if git_repo_name:
            # Use file_diff module to get updated file list. For backward compatibility
            checksum_list = file_diff.get_checksum_list(contract_file_paths)
            contract_file_paths = file_diff.get_updated_files(
                git_repo_name=git_repo_name,
                file_type=AdmSchemaFileType.CONTRACT.value,
                checksum_table_name=checksum_table_name,
                checksum_list=checksum_list
            )
            logger.info(f"Found updated contract files: {contract_file_paths}")

        for file_path in contract_file_paths:
            logger.info(f"Process contract file {file_path}")
            contract = ut.AdmConfig.load_config_file(file_path, session_variables=None)

            if ut.AdmSpark.get_spark_session().catalog.tableExists(contract.table_name):
                update_comment_and_tags(contract)
                update_rls(contract)
                update_cls(contract)
                if os.environ["MFL_RUNTIME_ENV"]=='dev':
                    update_permission(contract)
                #update_table_schema_by_contract(file_path)
            else:
                logger.warning(f"Table {contract.table_name} doesn't exist!")
                if git_repo_name:
                    # Don't build checksum since table doesn't exist yet
                    checksum_list.remove(next(x for x in checksum_list if x[0]==file_path))

        if git_repo_name:
            # Update checksum table. For backward compatibility
            file_diff.upsert_checksum_table(
                git_repo_name=git_repo_name,
                file_type=AdmSchemaFileType.CONTRACT.value,
                checksum_table_name=checksum_table_name,
                checksum_list=checksum_list
            )

            # Delete deprecated contract file checksum
            file_diff.delete_deprecated_rows_from_checksum_table(
                git_repo_name=git_repo_name,
                file_type=AdmSchemaFileType.CONTRACT.value,
                checksum_table_name=checksum_table_name,
                checksum_list=checksum_list
            )

def process_crud_files(
        project_root_path: str,
        crud_file_path_list: list[str],
        git_repo_name: str=None,
        checksum_table_name: str=None
):
    """_summary_

    Args:
        project_root_path (str): _description_
        crud_file_path_list (list[str]): _description_
        git_repo_name (str, optional): _description_. Defaults to None.
    """
    for crud_file_path in crud_file_path_list:
        crud_file_paths = find_yaml_files(os.path.join(project_root_path, crud_file_path))

#        if git_repo_name:
#            # Use file_diff module to get updated file list. For backward compatibility
#            checksum_list = file_diff.get_checksum_list(crud_file_paths)
#            crud_file_paths = file_diff.get_updated_files(
#                git_repo_name=git_repo_name,
#                file_type=AdmSchemaFileType.CRUD.value,
#                checksum_table_name=checksum_table_name,
#                checksum_list=checksum_list
#            )

        for file_path in crud_file_paths:
            logger.info(f"Process crud file {file_path}")
            skipped = run_crud_operations(file_path)
#            if git_repo_name and skipped:
#                checksum_list.remove(next(x for x in checksum_list if x[0]==file_path))

#        if git_repo_name:
#            # Update checksum table. For backward compatibility
#            file_diff.upsert_checksum_table(
#                git_repo_name=git_repo_name,
#                file_type=AdmSchemaFileType.CRUD.value,
#                checksum_table_name=checksum_table_name,
#                checksum_list=checksum_list
#            )

            # Delete deprecated contract file checksum

#            file_diff.delete_deprecated_rows_from_checksum_table(
#                git_repo_name=git_repo_name,
#                file_type=AdmSchemaFileType.CRUD.value,
#                checksum_table_name=checksum_table_name,
#                checksum_list=checksum_list
#            )


def main(args=None):
    """_summary_
    """

    parser = argparse.ArgumentParser()

    parser.add_argument(
        '--runtime_env',
        type=str,
        metavar='runtime_env',
        required=True,
        help='runtime_env'
    )

    parser.add_argument(
        '--project_root_path',
        type=str,
        metavar='project_root_path',
        required=True,
        help='project_root_path'
    )

    parser.add_argument(
        '--env_file_path',
        type=str,
        metavar='env_file_path',
        required=True,
        help='env_file_path'
    )

    parser.add_argument(
        '--contract_file_path_list',
        nargs='+',
        type=str,
        metavar='contract_file_path_list',
        required=True,
        help='contract file path list'
    )

    parser.add_argument(
        '--crud_file_path_list',
        nargs='+',
        type=str,
        metavar='crud_file_path_list',
        required=True,
        help='CRUD file path list'
    )

    args = parser.parse_args(args)

    ut.AdmConfig.load_sys_env_var(
        runtime_env=args.runtime_env,
        project_root_path=args.project_root_path,
        env_file_path=args.env_file_path
    )

    checksum_table_name = f"{os.environ['MFL_SKM_ADM_SYSTEM']}.adm_table_schema_file_checksum"
    file_diff.get_create_checksum_table(checksum_table_name)

    logger.info("Start processing contract files...")
    process_contract_files(
        project_root_path=args.project_root_path,
        contract_file_path_list=args.contract_file_path_list,
        git_repo_name=os.getenv('MFL_GIT_REPO_NAME'),
        checksum_table_name = checksum_table_name
    )

    logger.info("Start processing CRUD files...")
    process_crud_files(
        project_root_path=args.project_root_path,
        crud_file_path_list=args.crud_file_path_list,
        git_repo_name=os.getenv('MFL_GIT_REPO_NAME'),
        checksum_table_name = checksum_table_name
    )


if __name__ == "__main__":
    main()
