"""_summary_
"""

import hashlib
import pyspark.sql.functions as F
from loguru import logger

import admcore.utils as ut


def get_create_checksum_table(
        table_name: str
):
    """_summary_

    Args:
        table_name (str): _description_
    """

    if ut.AdmSpark.get_spark_session().catalog.tableExists(table_name) is False:
        sql = f"""CREATE TABLE IF NOT EXISTS {table_name}(
                    git_repo_name STRING,
                    file_type STRING,
                    file_path STRING,
                    checksum STRING,
                    last_updated TIMESTAMP
                )"""
        ut.AdmSpark.get_spark_session().sql(sql)


def generate_checksum(
        file_path: str
) -> str:
    """_summary_

    Args:
        file_path (str): _description_

    Returns:
        str: _description_
    """
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as f:
        while chunk := f.read(8192):
            sha256.update(chunk)
    return sha256.hexdigest()


def get_checksum_list(
        file_path_list: list[str]
) -> list:
    """_summary_

    Args:
        file_path_list (list[str]): _description_

    Returns:
        list: _description_
    """

    checksum_list = []
    for file_path in file_path_list:
        logger.info(f"Generating checksum for file {file_path}")
        checksum = generate_checksum(file_path)
        checksum_list.append([file_path, checksum])
    return checksum_list


def get_updated_files(
        git_repo_name: str,
        file_type: str,
        checksum_table_name: str,
        checksum_list: list
) -> list[str]:
    """_summary_

    Args:
        folder (str): _description_

    Returns:
        list[str]: _description_
    """

    if len(checksum_list) == 0:
        return []

    df_file = ut.AdmSpark.get_spark_session().createDataFrame(
            data=checksum_list,
            schema=['file_path', 'checksum']
    )

    sql = f"""SELECT file_path, checksum FROM {checksum_table_name}
            WHERE git_repo_name='{git_repo_name}' and file_type='{file_type}'"""
    logger.debug(sql)

    df_table = ut.AdmSpark.get_spark_session().sql(sql)

    df = df_file.join(df_table, on=['file_path', 'checksum'], how='left_anti')
    diff_file_paths = [row[0] for row in df.select("file_path").collect()]

    return diff_file_paths


def upsert_checksum_table(
        git_repo_name: str,
        file_type: str,
        checksum_table_name: str,
        checksum_list: list
):
    """_summary_

    Args:
        git_repo_name (str): _description_
        checksum_table_name (str): _description_
        checksum_list (list): _description_
    """

    if len(checksum_list) > 0:
        df = ut.AdmSpark.get_spark_session().createDataFrame(
            data=checksum_list,
            schema=['file_path', 'checksum']
        )

        df_table = ut.AdmSpark.get_spark_session().sql(
            f"SELECT file_path, checksum FROM {checksum_table_name} WHERE git_repo_name='{git_repo_name}' AND file_type='{file_type}'"
        )

        df_updated = df.join(df_table, on=['file_path', 'checksum'], how='left_anti')

        df_updated = (
            df_updated.withColumn('git_repo_name', F.lit(git_repo_name))
                .withColumn('last_updated', F.current_timestamp())
                .withColumn('file_type', F.lit(file_type))
        )

        logger.info(f"Upsert checksum for files: {[row[0] for row in df_updated.select('file_path').collect()]}")

        ut.AdmSpark.df_to_table_upsert(
            df=df_updated,
            keys=['git_repo_name', 'file_path'],
            table_name=checksum_table_name
        )


def delete_deprecated_rows_from_checksum_table(
        git_repo_name: str,
        file_type: str,
        checksum_table_name: str,
        checksum_list: list
):
    """_summary_

    Args:
        git_repo_name (str): _description_
        checksum_table_name (str): _description_
        checksum_list (list): _description_
    """
    if len(checksum_list) > 0:
        sp = ut.AdmSpark.get_spark_session()

        df = sp.createDataFrame(
            data=checksum_list,
            schema=['file_path', 'checksum']
        )

        df_table = sp.sql(
            f"SELECT file_path, checksum FROM {checksum_table_name} WHERE git_repo_name='{git_repo_name}' AND file_type='{file_type}'"
        )

        df_deprecated = df_table.join(df, on=['file_path'], how='left_anti')
        df_deprecated.createOrReplaceTempView("adm_core_file_diff_to_delete")

        delta_table = ut.AdmSpark.get_delta_table(checksum_table_name)

        logger.info(f"Delete checksum for files: {[row[0] for row in df_deprecated.select('file_path').collect()]}")

        delta_table.alias("target").merge(
            source=sp.table("adm_core_file_diff_to_delete").alias("source"),
            condition=f"target.file_path = source.file_path AND target.git_repo_name='{git_repo_name}'"
        ).whenMatchedDelete().execute()
