"""Assign permissions to team members in dev environment
"""

import os
from loguru import logger
from pyspark.errors import PySparkException
import admcore.utils as ut


def get_security_function_information(
        security_catalog_name: str,
        table_name: str
) -> list[tuple]:
    """_summary_
    """

    sql = f"""SELECT routine_name, routine_schema, routine_owner 
        FROM edp_ref_data_dev.information_schema.routines
        WHERE routine_type='FUNCTION' AND routine_name LIKE '%{table_name.replace(".", "_")}'"""

    df = ut.AdmSpark.get_spark_session().sql(sql)
    func_list = [row.asDict() for row in df.collect()]

    result = [(f"{security_catalog_name}.{x['routine_schema']}.{x['routine_name']}", x['routine_owner']) for x in func_list]

    return result


def grant_table_permission(
        table_name: str,
        privileges: list[str],
        principal: str 
):
    """_summary_

    Args:
        table_name (str): _description_
        privileges (list[str]): _description_
        principal (str): _description_
    """
    sql = f"""
            GRANT {','.join(privileges)} ON TABLE {table_name} TO {principal};
          """
    logger.info(sql)

    try:
        ut.AdmSpark.get_spark_session().sql(sql)
    except PySparkException as e:
        if e.getErrorClass() == 'UNAUTHORIZED_ACCESS':
            logger.error(f"No permission to run GRANT on table {table_name}. Contact the owner of this table to run update_table_schema workflow.")
            table_info = table_name.split('.')
            logger.info(f"SQL to find table owner: SELECT table_owner FROM {table_info[0]}.information_schema.tables where table_name='{table_info[2]}' and table_schema='{table_info[1]}' and table_catalog='{table_info[0]}'")
        else:
            raise e


def grant_security_function_permission(
        table_name: str,
        privileges: list[str],
        principal: str
):
    """_summary_

    Args:
        table_name (str): _description_
        privileges (list[str]): _description_
        principal (str): _description_
    """
    func_list = get_security_function_information(
        security_catalog_name=f'edp_ref_data_{os.environ["MFL_RUNTIME_ENV"]}',
        table_name=table_name
    )

    for func in func_list:
        func_name = func[0]
        func_owner = func[1]

        sql = f"""
                GRANT {','.join(privileges)} ON FUNCTION {func_name} TO {principal};
              """
        logger.info(sql)

        try:
            ut.AdmSpark.get_spark_session().sql(sql)
        except PySparkException as e:
            if e.getErrorClass() == 'UNAUTHORIZED_ACCESS':
                logger.error(f"No permission to run GRANT on Function {func_name}. Contact {func_owner} to run update_table_schema workflow.")
            else:
                raise e


def update_permission(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """
    if 'security' in contract and 'db_object_permission' in contract.security:
        for permission in contract.security.db_object_permission:
            for principal in permission.principals:
                grant_table_permission(
                    table_name=contract.table_name,
                    privileges=permission.privilege_types,
                    principal=principal
                )

                grant_security_function_permission(
                    table_name=contract.table_name,
                    privileges=permission.privilege_types,
                    principal=principal
                )
