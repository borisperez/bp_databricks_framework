"""security:
     row_level:
       enable: true
       column_names: []
       entitlement_table:
       function:
         name:
         sql:
"""

import os
from loguru import logger
import admcore.utils as ut


def get_default_function_name(
        contract
) -> str:
    """_summary_

    Args:
        contract (_type_): _description_

    Returns:
        str: _description_
    """

    env = os.environ["MFL_RUNTIME_ENV"]
    ent_table_name = contract.table_name.replace('.', '_')
    function_name = f'edp_ref_data_{env}.entitlement.rls_default_{ent_table_name}'

    return function_name


def create_default_filter_function(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    rls = contract.security.row_level

    if isinstance(rls.column_name, str):
        rls.column_names = [rls.column_name]

    rls_col = next((col for col in contract.schema.columns if col.name == rls.column_names[0]), None)
    if rls_col is None:
        raise ut.AdmError(f"{rls.column_names[0]} doesn't exist in table {contract.table_name}")

    if 'service_principal_group' in rls and rls.service_principal_group:
        admin_group_condition = ''.join("IS_ACCOUNT_GROUP_MEMBER('" + group + "') OR " for group in rls.service_principal_group)
    else:
        admin_group_condition = ''

    sql = f"""CREATE OR REPLACE FUNCTION {get_default_function_name(contract)}({rls.column_names[0]} {rls_col.type})
              RETURNS BOOLEAN
              RETURN (
                {admin_group_condition}
                ({rls.column_names[0]} in (SELECT rls_value FROM {rls.entitlement_table} where LOWER(user_name) = LOWER(current_user())))
              )
          """
    logger.info(sql)
    ut.AdmSpark.get_spark_session().sql(sql)


def apply_default_filter_function(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    rls = contract.security.row_level

    if isinstance(rls.column_name, str):
        rls.column_names = [rls.column_name]

    sql = f"""ALTER TABLE {contract.table_name}
              SET ROW FILTER {get_default_function_name(contract)} ON ({rls.column_names[0]});"""
    logger.info(sql)

    ut.AdmSpark.get_spark_session().sql(sql)


def create_customized_filter_function(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    rls = contract.security.row_level

    columns = []
    for column_name in rls.column_name:
        column = next((col for col in contract.schema.columns if col.name == column_name), None)
        if column is None:
            raise ut.AdmError(f"{column_name} doesn't exist in table {contract.table_name}")
        columns.append(f"{column.name} {column.type}")

    if rls.function.sql.endswith('.yml') or rls.function.sql.endswith('.yaml'):
        func_sql = ut.AdmConfig.load_config_file(rls.function.sql, session_variables=None).sql
    else:
        func_sql = rls.function.sql

    sql = f"""CREATE OR REPLACE FUNCTION {rls.function.name}({','.join(columns)})
              RETURNS BOOLEAN
              RETURN ({func_sql})
              );
           """

    logger.info(sql)

    ut.AdmSpark.get_spark_session().sql(sql)


def apply_customized_filter_function(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    rls = contract.security.row_level

    sql = f"""ALTER TABLE {contract.table_name}
              SET ROW FILTER {rls.function.name} ON ({','.join(rls.column_name)});"""

    logger.info(sql)

    ut.AdmSpark.get_spark_session().sql(sql)


def drop_rls(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    sql = f"""ALTER TABLE {contract.table_name} DROP ROW FILTER"""
    logger.info(sql)
    ut.AdmSpark.get_spark_session().sql(sql)


def update_rls(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    sp = ut.AdmSpark.get_spark_session()

    if not sp.catalog.tableExists(contract.table_name):
        logger.warning(f"Table {contract.table_name} doesn't exist")
        return

    if 'security' in contract and 'row_level' in contract.security:
        rls = contract.security.row_level
        if rls.enable:
            if ('function' in rls and
                    'name' in rls.function and
                    rls.function.name and
                    len(rls.function.name) > 0 and
                    'sql' in rls.function and 
                    rls.function.sql and
                    len(rls.function.sql) > 0):
                # Customized function
                create_customized_filter_function(contract)
                apply_customized_filter_function(contract)
            else:
                # Use default function
                create_default_filter_function(contract)
                apply_default_filter_function(contract)
        else:
            # Drop RLS function from table if enable flag is false
            drop_rls(contract)

    else:
        # Drop RLS function from table
        drop_rls(contract)
