"""_summary_
"""

import importlib
import os
from loguru import logger

import admcore.utils as ut


def get_default_cls_function_name(
        target_table_name: str,
        template_function_name: str,
        conditional_cls: bool=False
) -> str:
    """_summary_

    Args:
        target_table_name (str): _description_
        template_function_name (str): _description_
        conditional_cls (bool, optional): _description_. Defaults to False.

    Returns:
        str: _description_
    """

    env = os.environ["MFL_RUNTIME_ENV"]
    table_name_part = target_table_name.replace('.', '_')
    if conditional_cls:
        function_name = f'`edp_ref_data_{env}`.`entitlement`.`{template_function_name}_conditional_{table_name_part}`'
    else:
        function_name = f'`edp_ref_data_{env}`.`entitlement`.`{template_function_name}_{table_name_part}`'

    return function_name


def get_create_cls_function(
        module_path: str,
        table_name: str,
        service_principal_groups: list[str],
        entitlement_table_name: str,
        conditional_cls: bool,
        rls_column: str
) -> str:
    """_summary_

    Args:
        service_principal_groups (list[str]): _description_
        entitlement_table_name (str): _description_

    Returns:
        str: _description_
    """

    module_name = module_path.split(':')[0]
    function_name = module_path.split(':')[1]

    module = importlib.import_module(module_name)
    cls_function = getattr(module, function_name)

    cls_function_name = get_default_cls_function_name(table_name, function_name)

    function_creating_sql = cls_function(
        cls_function_name,
        service_principal_groups,
        entitlement_table_name,
        conditional_cls,
        rls_column
    )

    logger.debug(f"function_creating_sql: {function_creating_sql}")

    ut.AdmSpark.get_spark_session().sql(function_creating_sql)

    return cls_function_name


def disable_cls_all(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """
    for mask_policy in contract.security.column_level.mask_policy:
        for column_name in mask_policy.column_names:
            sql = f"""ALTER TABLE {contract.table_name} 
                      ALTER COLUMN {column_name}
                        DROP MASK
                   """
            logger.info(sql)
            ut.AdmSpark.get_spark_session().sql(sql)


def get_masked_columns(
        table_name: str
) -> list[tuple]:
    """_summary_

    Args:
        table_name (str): _description_

    Returns:
        list[tuple]: [(column_name, cls_function_name)]
    """

    df = ut.AdmSpark.get_spark_session().sql(f"DESCRIBE TABLE EXTENDED {table_name}")
    rows = df.collect()

    # Step 1: Find start index of "# Column Masks"
    start_index = next(
        (i for i, row in enumerate(rows) if row['col_name'] == '# Column Masks'), None
    )

    masked_columns = []

    if start_index is not None:
        # Step 2: Iterate rows after the section header
        for row in rows[start_index + 1:]:
            col_name = row['col_name']
            data_type = row['data_type']

            # Stop if the next metadata section begins
            if col_name.startswith('#'):
                break

            masked_columns.append((col_name, data_type))

    return masked_columns


def update_cls_columns(
    contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    admin_group = contract.security.column_level.service_principal_group
    ent_table = contract.security.column_level.entitlement_table

    conditional_cls = False
    rls_column = None
    if 'conditional_cls' in contract.security.column_level:
        conditional_cls = contract.security.column_level.conditional_cls
        rls_column_name = contract.security.column_level.conditional_column_name

        if conditional_cls:
            rls_col = next(
                (col for col in contract.schema.columns if col.name == rls_column_name),
                None
            )
            rls_column_type = rls_col.type

            rls_column = (rls_column_name, rls_column_type)

    masked_columns = get_masked_columns(contract.table_name)

    contract_mask_column_names = []

    for mask_policy in contract.security.column_level.mask_policy:
        # Always replace CLS functions
        #logger.info(f"mask_policy being worked on {mask_policy}")
        cls_function_name = get_create_cls_function(
            mask_policy.function,
            contract.table_name,
            admin_group,
            ent_table,
            conditional_cls,
            rls_column
        )

        for column_name in mask_policy.column_names:

            if (column_name, cls_function_name) not in masked_columns:
                # Mask columns that are not in masked column list
                if conditional_cls:
                    sql = f"""ALTER TABLE {contract.table_name} 
                              ALTER COLUMN {column_name}
                              SET MASK {cls_function_name}
                              USING COLUMNS('{column_name}', '{ent_table}', {rls_column[0]})
                          """
                    logger.info("Attached the mask and unmask policy to masked column")
                    logger.info(sql)
                else:
                    sql = f"""ALTER TABLE {contract.table_name}
                          ALTER COLUMN {column_name}
                            SET MASK {cls_function_name}
                            USING COLUMNS('{column_name}', '{ent_table}')
                          """
                    logger.info("Attached the mask and unmask policy to masked column")
                    logger.info(sql)

                ut.AdmSpark.get_spark_session().sql(sql)

            contract_mask_column_names.append(column_name)

    for masked_column in masked_columns:
        if masked_column[0] not in contract_mask_column_names:
            sql = f"""ALTER TABLE {contract.table_name}
                      ALTER COLUMN {masked_column[0]}
                        DROP MASK
                   """
            logger.info(sql)
            ut.AdmSpark.get_spark_session().sql(sql)


def update_cls(
        contract
):
    """_summary_

    Args:
        contract (_type_): _description_
    """

    sp = ut.AdmSpark.get_spark_session()

    if not sp.catalog.tableExists(contract.table_name):
        logger.warning(f"Table {contract.table_name} doesn't exist")
        return

    if 'security' in contract and 'column_level' in contract.security:
        if contract.security.column_level.enable:
            # Update masked columns based on column_level config.
            # Either mask a column or unmask a column.
            update_cls_columns(contract)
        else:
            # unmask all columns
            disable_cls_all(contract)
