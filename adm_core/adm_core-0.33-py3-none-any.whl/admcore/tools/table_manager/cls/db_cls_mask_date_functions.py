"""_summary_
"""

from admcore.tools.table_manager.cls.db_cls_common import get_condition_cls_argument, get_unmask_condition


def cls_mask_date_string(
        function_name: str,
        service_principal_groups: list[str],
        entitlement_table_name: str,
        conditional_cls: bool,
        rls_column: str
)->str:
    """_summary_

    Args:
        function_name (str): _description_
        service_principal_groups (list[str]): _description_
        entitlement_table_name (str): _description_

    Returns:
        str: _description_
    """
    sql = f"""CREATE OR REPLACE FUNCTION {function_name}(
                    column_value string,
                    column_name string,
                    entitlement_table_name string
                    {get_condition_cls_argument(conditional_cls, rls_column)}
                )
                RETURNS string
                RETURN
                CASE
                    {get_unmask_condition(service_principal_groups, entitlement_table_name,conditional_cls,rls_column)}
                    ELSE
                        CAST('9999-12-31' AS string)
                END
            """

    return sql


def cls_mask_date_to_staticdate(
        function_name: str,
        service_principal_groups: list[str],
        entitlement_table_name: str,
        conditional_cls: bool,
        rls_column: str
)->str:
    """_summary_

    Args:
        function_name (str): _description_
        service_principal_groups (list[str]): _description_
        entitlement_table_name (str): _description_

    Returns:
        str: _description_
    """
    sql = f"""CREATE OR REPLACE FUNCTION {function_name}(
                    column_value string,
                    column_name string,
                    entitlement_table_name string
                    {get_condition_cls_argument(conditional_cls, rls_column)}
                )
                RETURNS date
                RETURN
                CASE
                    {get_unmask_condition(service_principal_groups, entitlement_table_name,conditional_cls,rls_column)}
                    ELSE
                        CAST('9999-12-31' as date)
                END
            """

    return sql