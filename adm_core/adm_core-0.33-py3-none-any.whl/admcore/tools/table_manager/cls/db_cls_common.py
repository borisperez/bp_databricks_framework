"""_summary_
"""

def get_admin_group_condition(
        service_principal_groups: list[str],
) -> str:
    """_summary_

    Args:
        service_principal_groups (list[str]): _description_

    Returns:
        str: _description_
    """

    if service_principal_groups:
        admin_group_condition = ' OR '.join("IS_ACCOUNT_GROUP_MEMBER('" + group + "') " for group in service_principal_groups)
    else:
        admin_group_condition = ''
    
    return admin_group_condition


def get_default_unmask_condition(
        service_principal_groups: list[str],
        entitlement_table_name: str
) -> str:
    """This is a helper function to get sub SQL statement for checking if the current user belong to
    service principal groups.

    Args:
        service_principal_groups (list[str]): _description_

    Returns:
        str: _description_
    """

    admin_group_condition = get_admin_group_condition(service_principal_groups)

    sql_part = f"""
                    WHEN 
                        {admin_group_condition}
                    THEN
                        column_value
                    WHEN
                        column_name in (SELECT unmask_column FROM {entitlement_table_name} WHERE LOWER(user_name)=LOWER(current_user()))
                    THEN
                        column_value
                """

    return sql_part


def get_conditional_unmask_condition(
        service_principal_groups: list[str],
        entitlement_table_name: str,
        rls_column: tuple
) -> str:
    """_summary_

    Args:
        service_principal_groups (list[str]): _description_
        entitlement_table_name (str): _description_
        rls_column (tuple): (column_name, column_type)

    Returns:
        str: _description_
    """
    admin_group_condition = get_admin_group_condition(service_principal_groups)

    sql_part = f"""
                    WHEN 
                        {admin_group_condition}
                    THEN
                        column_value
                    WHEN
                        column_name in (select unmask_column FROM {entitlement_table_name} 
                                        where lower(user_name)=lower(current_user())
                                        )  AND 
                        {rls_column[0]} in (select rls_value from {entitlement_table_name}
                                        where lower(unmask_column)=lower(column_name)
                                        )
                    THEN
                        column_value
                """
    
    return sql_part


def get_unmask_condition(
        service_principal_groups: list[str],
        entitlement_table_name: str,
        conditional_cls: bool,
        rls_column: str
) -> str:
    """_summary_

    Args:
        service_principal_groups (list[str]): _description_
        entitlement_table_name (str): _description_
        conditional_cls (bool): _description_
        rls_column (str): _description_

    Returns:
        str: _description_
    """

    return (
        get_default_unmask_condition(
            service_principal_groups, entitlement_table_name
        ) if conditional_cls is False else
        get_conditional_unmask_condition(
            service_principal_groups, entitlement_table_name, rls_column
        )
    )

def get_condition_cls_argument(
        conditional_cls: bool,
        rls_column: tuple
) -> str:
    """_summary_

    Args:
        conditional_cls (bool): _description_
        rls_column (str): (column_name, column_type)

    Returns:
        str: _description_
    """

    condition_argument = f",{rls_column[0]} {rls_column[1]}" if conditional_cls else ""
    return condition_argument
