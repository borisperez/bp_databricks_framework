"""This file keep all mask functions for column level security in Databricks
"""


from admcore.tools.table_manager.cls.db_cls_common import (
    get_condition_cls_argument,
    get_unmask_condition
)


def cls_mask_string(
        function_name: str,
        service_principal_groups: list[str],
        entitlement_table_name: str,
        conditional_cls: bool,
        rls_column: str
) -> str:
    """Default function to mask values of string columns. It returns masked values like "txxxm"

    Args:
        function_name (str): CLS function name
        service_principal_groups (list[str]): _description_
        column_name (str): _description_
        entitlement_table_name (str): _description_

    Returns:
        str: _description_
    """
    sql = f"""CREATE OR REPLACE FUNCTION {function_name}(
                    column_value string,
                    column_name string,
                    entitlement_table_name string
                    {get_condition_cls_argument(conditional_cls, rls_column)}
                )
                RETURNS string
                RETURN
                CASE
                    {get_unmask_condition(service_principal_groups, entitlement_table_name,conditional_cls,rls_column)}
                    ELSE
                        CASE 
                            WHEN LENGTH(column_value) > 4
                            THEN
                                CONCAT(
                                    SUBSTRING(column_value, 1, 2), 
                                    '***', 
                                    SUBSTRING(column_value, LENGTH(column_value) - 1, 2)
                                )
                            ELSE
                                '***'
                        END
                END
            """

    return sql


def cls_mask_integer_string(
        function_name: str,
        service_principal_groups: list[str],
        entitlement_table_name: str,
        conditional_cls: bool,
        rls_column: str
)->str:
    """_summary_

    Args:
        function_name (str): _description_
        service_principal_groups (list[str]): _description_
        entitlement_table_name (str): _description_

    Returns:
        str: _description_
    """
    sql = f"""CREATE OR REPLACE FUNCTION {function_name}(
                    column_value string,
                    column_name string,
                    entitlement_table_name string
                    {get_condition_cls_argument(conditional_cls, rls_column)}
                )
                RETURNS string
                RETURN
                CASE
                    {get_unmask_condition(service_principal_groups, entitlement_table_name,conditional_cls,rls_column)}
                    ELSE
                        CAST(FLOOR(RAND() * 1000000) AS string)
                END
            """

    return sql


def cls_mask_email(
        function_name: str,
        service_principal_groups: list[str],
        entitlement_table_name: str,
        conditional_cls: bool,
        rls_column: str
) -> str:
    """_summary_

    Args:
        function_name (str): _description_
        service_principal_groups (list[str]): _description_
        entitlement_table_name (str): _description_

    Returns:
        str: _description_
    """

    sql = f"""CREATE OR REPLACE FUNCTION {function_name}(
                    column_value string,
                    column_name string,
                    entitlement_table_name string
                    {get_condition_cls_argument(conditional_cls, rls_column)}
                )
                RETURNS string
                RETURN
                CASE
                    {get_unmask_condition(service_principal_groups, entitlement_table_name,conditional_cls,rls_column)}
                    ELSE
                        CONCAT(
                            SUBSTRING(column_value, 1, 1),
                            '***',
                            SUBSTRING(column_value, INSTR(column_value, '@') - 1, 1),
                            '@',
                            SUBSTRING(column_value, INSTR(column_value, '@') + 1)
                        )
                END
            """

    return sql
