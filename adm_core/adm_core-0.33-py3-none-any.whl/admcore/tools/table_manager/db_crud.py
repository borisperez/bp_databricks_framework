"""_summary_
"""

from loguru import logger
from pyspark.sql.utils import AnalysisException
import admcore.utils as ut


def run_crud_operations(
        file_path: str
) -> bool:
    """_summary_

    Args:
        file_path (str): _description_

    Raises:
        e: _description_

    Returns:
        bool: _description_
    """

    crud_conf = ut.AdmConfig.load_config_file(
        config_file_path=file_path,
        session_variables=None
    )

    skipped = False

    # Only run valid db_crud config files
    if "crud_operations" in crud_conf:
        for crud_op in crud_conf.crud_operations:
            if crud_op.enable:
                logger.info(f"{crud_op.name} started")

                if crud_op.sql.endswith('.yml') or crud_op.sql.endswith('.yaml'):
                    sql = ut.AdmConfig.load_config_file(
                        config_file_path=crud_op.sql,
                        session_variables=None
                    ).sql
                else:
                    sql = crud_op.sql

                logger.info(f"sql: {sql}")
                try:
                    ut.AdmSpark.get_spark_session().sql(sql)
                except AnalysisException as e:
                    error_msg = str(e)
                    if "[TABLE_OR_VIEW_NOT_FOUND]" in error_msg:
                        skipped = True
                        logger.warning(f"Missing table: {error_msg.split('. ', 1)[0]}")
                        logger.warning(f"CRUD execution [name={crud_op.name}] for file {file_path} is skipped!")
                    else:
                        raise e
            else:
                logger.info(f"{crud_op.name} skipped.")

    return skipped
