"""_summary_
"""

import importlib
import os

from pyspark.sql import DataFrame
from loguru import logger

import admcore.pipeline as pl
import admcore.utils as ut


class AdmDebugger:
    """_summary_
    """

    def __init__(
            self,
            databricks_path: str,
            pipeline_file_path: str,
            project_root_path: str = 'src',
            env_file_path: str = 'src/env.toml',
            runtime_env: str = 'dev'
            ):
        """_summary_

        Args:
            databricks_path (str): Absolute path to the bundle files on Databricks
            pipeline_file_path (str): Relative pipeline config file path. e.g. src/pl_1/pipeline.yml
            project_root_path (str): Relative path to project file
            env_file_path (str): Relative path to env.toml file
        """

        os.chdir(databricks_path)

        self.pl_config = pl.prepare(
            runtime_env=runtime_env,
            project_root_path=project_root_path,
            env_file_path=env_file_path,
            pl_file_path=pipeline_file_path
        )

        self.pipeline_file_path = pipeline_file_path

    def debug_function(
            self,
            input_data: DataFrame | str,
            task_name: str,
            action_name: str,
            function_name: str
    ) -> DataFrame:
        """_summary_

        Args:
            input_data (DataFrame | str): Either a Spark DataFrame from previous Function or a temp view or None 
            task_name (str): Task key in pipeline.yml file
            action_name (str): Action name in task config file
            function_name (str): Function name in the Action

        Returns:
            DataFrame: Spark DataFrame which is the output of this Function
        """

        pl_task = self.pl_config.tasks[task_name]
        if pl_task.enable is None:
            raise ut.AdmError(f"Task {task_name} is disabled in config file {self.pipeline_file_path}")
        task_file_path = pl_task.config_file_path

        task = ut.AdmConfig.load_config_file(
            config_file_path=task_file_path,
            session_variables=self.pl_config.session_variables
        )

        if isinstance(input_data, str):
            # Input is Spark temp view
            df = ut.AdmSpark.get_spark_session().sql(f"SELECT * FROM {input}")
        else:
            df = input_data

        action = next(
            (item for item in task.actions if item["name"] == action_name),
            None
        )

        if action is None:
            raise ut.AdmError(f'Action "{action_name}" is not in config file {task_file_path}')

        func = next(
            (item for item in action.functions if item["name"] == function_name),
            None
        )

        if func is None:
            raise ut.AdmError(f'Function "{function_name}" is not in action "{action_name}"')


        if func.enable:
            logger.info(f"Function '{func.name}' started")

            module_name = func.module_file_path.split(':')[0]
            function_name = func.module_file_path.split(':')[1]

            module = importlib.import_module(
                    module_name
            )
            function = getattr(module, function_name)

            return_data = function(df, func, action, task, self.pl_config)

            logger.info(f"Function '{func.name}' finished. Either a Spark DataFrame is returned or a temp view is created based on your config")

            return return_data
        else:
            logger.info(f"Function '{func.name}' disabled")
            return None
