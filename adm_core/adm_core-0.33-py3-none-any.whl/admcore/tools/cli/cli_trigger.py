"""_summary_
"""


import os
from pathlib import Path
import click
import yaml

from admcore.tools.cli.cli_common import NoAliasDumper, get_project_name, prompt_project_root_path


def prompt_pipeline_path() -> str:
    """_summary_

    Returns:
        str: _description_
    """

    while 1:
        pipeline_path = click.prompt("Input pipeline folder")
        if Path(pipeline_path).is_dir():
            break
        click.echo(f"pipeline folder {pipeline_path} doesn't exist or it's not a folder")

    return pipeline_path


def prompt_scheduler() -> tuple:
    """_summary_

    Returns:
        tuple: _description_
    """

    quartz_cron_expression = click.prompt(
        "Input quartz cron expression for your time scheduler. Refer to https://www.quartz-scheduler.org/documentation/quartz-2.3.0/tutorials/crontrigger.html"
    )

    timezone_id = click.prompt(
        "Input timezone ID",
        default='UTC'
    )

    return (quartz_cron_expression, timezone_id)


def prompt_file_arrival_trigger() -> tuple:
    """_summary_

    Returns:
        tuple: _description_
    """

    url = click.prompt(
        "Input the storage location of your files such as /Volumes/path_to_your_files/"
    )

    wait_after_last_change_seconds = click.prompt(
        "Input seconds after last change of files", type=int, default=60
    )

    return (url, wait_after_last_change_seconds)


def prompt_trigger_environment() -> list[str]:
    """_summary_

    Returns:
        list[str]: _description_
    """

    while 1:
        click.echo("Choose Which environments you want applying the trigger")
        click.echo("1. Dev")
        click.echo("2. QA")
        click.echo("3. Prod")
        environments: str = click.prompt(
            "Enter a number or multiple numbers separated by ','", type=str, default='3'
        )

        env_list = environments.split(",")
        if len(set(env_list) - set(['1', '2', '3'])) == 0:
            break

    mapped_env_list = ['dev' if x=='1' else 'qa' if x=='2' else 'prod' for x in env_list]

    return mapped_env_list


def prompt_trigger_type():
    """_summary_

    Returns:
        _type_: _description_
    """

    while 1:
        click.echo("Choose type of triggers by entering the number below")
        click.echo("1. Time scheduler")
        click.echo("2. File arrival trigger")
        trigger_type = click.prompt("Enter a number", type=int)

        if trigger_type in [1, 2]:
            break

    return trigger_type


def add_time_scheduler(
        db_file_path: str,
        workflow_name: str,
        env_list: list[str]
):
    """_summary_

    Args:
        db_file_path (str): _description_
        workflow_name (str): _description_
        env_list (list[str]): _description_
    """

    cron_expr, tz_id = prompt_scheduler()

    time_schedule = {
            'quartz_cron_expression': cron_expr,
            'timezone_id': tz_id,
            'pause_status': 'UNPAUSED'
    }

    with open(db_file_path, encoding='utf-8') as f:
        db_conf = yaml.safe_load(f)

    for env in env_list:
        db_conf['targets'][env]['resources']['jobs'][workflow_name]['schedule'] = time_schedule

    with open(db_file_path, mode='w', encoding='utf-8') as f:
        yaml.dump(db_conf, f, Dumper=NoAliasDumper, default_flow_style=False, sort_keys=False)


def add_file_trigger(
        db_file_path: str,
        workflow_name: str,
        env_list: list[str]
):
    """_summary_

    Args:
        db_file_path (str): _description_
        workflow_name (str): _description_
        env_list (list[str]): _description_
    """

    url, wait_seconds = prompt_file_arrival_trigger()

    with open(db_file_path, encoding='utf-8') as f:
        db_conf = yaml.safe_load(f)

    file_trigger = {
        "pause_status": "UNPAUSED",
        "file_arrival": {
          "url": url,
          "wait_after_last_change_seconds": wait_seconds
        }
    }

    for env in env_list:
        db_conf['targets'][env]['resources']['jobs'][workflow_name]['trigger'] = file_trigger

    with open(db_file_path, mode='w', encoding='utf-8') as f:
        yaml.dump(db_conf, f, Dumper=NoAliasDumper, default_flow_style=False, sort_keys=False)


def update_trigger():
    """_summary_
    """
    project_root_path = prompt_project_root_path()
    pipeline_path = prompt_pipeline_path()
    pipeline_name = pipeline_path.split('/')[-1]

    trigger_type = prompt_trigger_type()
    db_file_path = os.path.join(project_root_path, 'databricks.yml')
    workflow_name = f"bundle_{get_project_name(project_root_path)}_{pipeline_name}"

    if trigger_type == 1:
        # Time scheduler
        env_list = prompt_trigger_environment()
        add_time_scheduler(db_file_path, workflow_name, env_list)
    else:
        # File trigger
        env_list = prompt_trigger_environment()
        add_file_trigger(db_file_path, workflow_name, env_list)
