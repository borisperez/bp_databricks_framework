"""Code of command line tool adm_cli
"""

import os
import shutil
from pathlib import Path
from zipfile import ZipFile
import re
import click
import yaml


from admcore.tools.cli.cli_pipeline import create_new_pipeline
from admcore.tools.cli.cli_common import (
    prompt_author_email,
    prompt_databricks_cluster_id,
    prompt_template_zip_path,
    prompt_project_root_path,
    replace_placeholders
)
from admcore.tools.cli.cli_trigger import update_trigger


def create_folder(root_path: str, name: str):
    """_summary_

    Args:
        root_path (str): _description_
        name (str): _description_
    """
    folder = os.path.join(root_path, name)
    os.makedirs(name=folder, exist_ok=True)
    click.echo(f"Created folder: {folder}")


def prompt_project_name() -> str:
    """_summary_

    Returns:
        str: _description_
    """
    while(1):
        project_name = click.prompt("Input your project name (Only string, number and underscore allowed)")
        if (bool(re.match(r"^[a-zA-Z0-9_]+$", project_name))):
            break
        click.echo(f"Invalid project_name: {project_name}")
    
    return project_name


def prompt_pipeline_name(project_name: str) -> str:
    """_summary_

    Args:
        project_name (str): _description_

    Returns:
        str: _description_
    """
    while(1):
        pipeline_name = click.prompt("Input the name of your first pipeline (Only string, number and underscore allowed)")
        if pipeline_name == project_name:
            click.echo("pipeline_name can't be as same as project_name")
            continue
        if (bool(re.match(r"^[a-zA-Z0-9_]+$", pipeline_name))):
            break
        click.echo(f"Invalid project_name: {pipeline_name}")
    
    return pipeline_name


def prompt_azure_databricks_url(edp_info_file_path: str):
    """_summary_

    Args:
        edp_info_file_path (str): _description_

    Returns:
        _type_: _description_
    """

    with open(edp_info_file_path, encoding='utf-8') as f:
        edp_info = yaml.safe_load(f)

    while(1):
        click.echo("Choose Databricks workspace for this project")
        number = 1
        for workspace in edp_info['databricks']['workspaces']:
            click.echo(f"{number}. {workspace['name']}")
            number += 1

        workspace_number = click.prompt("Enter a number", type=int)
        if workspace_number > len(edp_info['databricks']['workspaces']):
            click.echo("Invalid workspace number!")
            continue

        workspace_url_dev = edp_info['databricks']['workspaces'][workspace_number-1]['url']['dev']
        workspace_url_qa = edp_info['databricks']['workspaces'][workspace_number-1]['url']['qa']
        workspace_url_prod = edp_info['databricks']['workspaces'][workspace_number-1]['url']['prod']
        break

    return (workspace_url_dev, workspace_url_qa, workspace_url_prod)


def init_new_project():
    """_summary_
    """
    click.echo("\nSteps below will help you to initialize your new project...")

    project_root_path = prompt_project_root_path()
    extracted_file_path = os.path.join(project_root_path, '.adm_tmp')

    project_root_path_posix = Path(os.path.abspath(project_root_path)).resolve().as_posix()
    project_git_repo_name = project_root_path_posix.split('/')[-1]

    template_zip_path = prompt_template_zip_path()

    with ZipFile(template_zip_path, 'r') as zip_file:
        zip_file.extractall(extracted_file_path)
        click.echo(f"Extracted folders and files to {extracted_file_path}")

    author_email = prompt_author_email()

    project_name = prompt_project_name()

    db_dev_workspace_url, db_qa_workspace_url, db_prod_workspace_url = prompt_azure_databricks_url(os.path.join(extracted_file_path, 'edp_info.yml'))

    pipeline_name = prompt_pipeline_name(project_name)

    db_cluster_id_dev = prompt_databricks_cluster_id('Dev')

    click.echo(f"\nStart initializing project {project_name}...")

    replace_placeholders({
        "project_root_path": project_root_path,
        "extracted_file_path": extracted_file_path,
        "project_git_repo_name": project_git_repo_name,
        "author_email": author_email,
        "project_name": project_name,
        "databricks_dev_workspace_url": db_dev_workspace_url,
        "databricks_qa_workspace_url": db_qa_workspace_url,
        "databricks_prod_workspace_url": db_prod_workspace_url,
        "pipeline_config_folder": pipeline_name,
        "pipeline_name": pipeline_name,
        "databricks_cluster_id_dev": db_cluster_id_dev
    })

    # Move updated folders and files to project_root_path
    for item in os.listdir(extracted_file_path):
        src_path = os.path.join(extracted_file_path, item)
        dest_path = os.path.join(project_root_path, item)

        shutil.move(src_path, dest_path)

    # Delete the temporary working folder
    shutil.rmtree(extracted_file_path)

def main():
    """_summary_
    """
    click.echo("\n")
    click.echo("Welcome to ADM command line tool. ADM-Cli will help you to initialize your project and create your first pipeline.")
    click.echo("Use POSIX path in all adm_cli input such as c:/project/something/")
    click.echo("\n")

    click.echo("Choose what you want ADM-Cli to do from this list by entering the number")
    click.echo("1. Initialize new project")
    click.echo("2. Create a new pipeline in your existing project")
    click.echo("3. add/Update trigger to an existing pipeline")
    cli_task_type = click.prompt("Enter a number", type=float)

    if cli_task_type == 1:
        init_new_project()
    elif cli_task_type == 2:
        create_new_pipeline()
    elif cli_task_type == 3:
        update_trigger()
    else:
        click.echo("Invalid choice! Exiting")

if __name__ == "__main__":
    main()
