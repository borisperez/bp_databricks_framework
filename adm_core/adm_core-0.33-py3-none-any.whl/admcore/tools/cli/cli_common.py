"""_summary_
"""
import os
import re
from typing import Dict

import click
import yaml


class NoAliasDumper(yaml.Dumper):
    """_summary_

    Args:
        yaml (_type_): _description_
    """
    def ignore_aliases(self, data):
        return True


def get_project_name(project_root_path: str) -> str:
    """_summary_

    Args:
        project_root_path (str): _description_

    Returns:
        str: _description_
    """
    edp_info_file_path = os.path.join(project_root_path, 'edp_info.yml')
    with open(edp_info_file_path, encoding='utf-8') as f:
        edp_info_config = yaml.safe_load(f)
        project_name = edp_info_config['project']['name']
        return project_name


def prompt_project_root_path() -> str:
    """_summary_

    Returns:
        str: _description_
    """

    project_root_path = click.prompt(text="Input your project root path", default="./")
    project_root_path = os.path.abspath(project_root_path)

    return project_root_path

def prompt_template_zip_path() -> str:
    """_summary_

    Returns:
        str: _description_
    """

    while(1):
        template_zip_path = click.prompt(text="Input the path of adm_project_template.zip file", default="./adm_core/adm_project_template.zip")
        if os.path.isfile(template_zip_path):
            break
        click.echo(f"invalid file path: {template_zip_path}")
    
    return template_zip_path


def prompt_author_email() -> str:
    """_summary_

    Returns:
        str: _description_
    """
    while(1):
        author_email = click.prompt("Input your email address")
        if bool(re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", author_email)):
            break
        click.echo(f"Invalid email address: {author_email}")
    return author_email


def prompt_databricks_cluster_id(env: str) -> str:
    """_summary_

    Args:
        env (str): _description_

    Returns:
        str: _description_
    """

    while(1):
        cluster_id = click.prompt(f"Input Databricks compute cluster ID for {env} environment")
        if cluster_id is not None and len(cluster_id.strip()) > 0:
            break
        click.echo("Invalid Databricks compute cluster ID")
    
    return cluster_id


def replace_folder_name(root_path: str, folder_name: str, name_mapping: Dict[str, str]) -> str:
    """Replace folder or file name

    Args:
        root_path (str): _description_
        folder_name (str): _description_

    Returns:
        str: _description_
    """

    pattern = r"\{\{(.*?)\}\}"
    matches = re.findall(pattern, folder_name)

    updated_folder_name = folder_name
    for match in matches:
        updated_folder_name = updated_folder_name.replace("{{" + match + "}}", name_mapping[match])

    os.rename(os.path.join(root_path, folder_name), os.path.join(root_path, updated_folder_name))

    return updated_folder_name


def is_binary_file(filepath, num_bytes=1024):
    """_summary_

    Args:
        filepath (_type_): _description_
        num_bytes (int, optional): _description_. Defaults to 1024.

    Returns:
        _type_: _description_
    """
    with open(filepath, 'rb') as f:
        chunk = f.read(num_bytes)
    return b'\0' in chunk  # If there's a null byte, it's likely a binary file


def replace_placeholders(name_mapping: Dict[str, str], display_result: bool=True):
    """_summary_

    Args:
        name_mapping (Dict[str, str]): _description_
        display_result (bool, optional): _description_. Defaults to True.
    """

    folder_placeholder_pattern = r"\{\{.*?\}\}"
    #adm_folders = [
    #    'src',
    #    'test',
    #    'workflows',
    #    '.github',
    #    '{{pipeline_config_folder}}',
    #    '{{project_name}}',
    #    name_mapping['pipeline_config_folder'],
    #    name_mapping['project_name']
    #]

    # Update template file first
    for root, dirs, files in os.walk(name_mapping['extracted_file_path']):
        #dirs[:] = [d for d in dirs if d in adm_folders]
        for file_name in files:
            if (bool(re.search(folder_placeholder_pattern, file_name))):
                file_name = replace_folder_name(root, file_name, name_mapping)

            # Parse and replace placeholders in all template files
            if is_binary_file(os.path.join(root, file_name)) is False:
                with open(os.path.join(root, file_name), 'r', encoding='utf-8') as f:
                    content = f.read()
                    for k, v in name_mapping.items():
                        content = content.replace(f"<<{k}>>", v)

                with open(os.path.join(root, file_name), 'w', encoding='utf-8') as fw:
                    fw.write(content)

    # Update dir names
    for root, dirs, files in os.walk(name_mapping['extracted_file_path']):
        #dirs[:] = [d for d in dirs if d in adm_folders]
        for dir_name in dirs:
            if (bool(re.search(folder_placeholder_pattern, dir_name))):
                replace_folder_name(root, dir_name, name_mapping)

    if display_result:
        # Display result
        for root, dirs, files in os.walk(name_mapping['extracted_file_path']):
            #dirs[:] = [d for d in dirs if d in adm_folders]
            click.echo(f"Directory: {root}")
            for dir_name in dirs:
                click.echo(f"  Subdirectory: {dir_name}")
            for file_name in files:
                click.echo(f"  File: {file_name}")
