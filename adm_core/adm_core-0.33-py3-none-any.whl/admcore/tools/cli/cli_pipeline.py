"""_summary_
"""

import os
import re
from pathlib import Path
import shutil
from zipfile import ZipFile

import yaml
import click

from admcore.tools.cli.cli_common import (
    get_project_name,
    prompt_author_email,
    prompt_databricks_cluster_id,
    prompt_template_zip_path,
    prompt_project_root_path,
    replace_placeholders
)


def prompt_new_pipeline_name() -> str:
    """_summary_

    Returns:
        str: _description_
    """
    while(1):
        pipeline_name = click.prompt("Input the name of your new pipeline (Only string, number and underscore allowed)")
        if (Path('./src') / pipeline_name).is_dir():
            click.echo(f"pipeline_name {pipeline_name} already exists")
            continue
        if (bool(re.match(r"^[a-zA-Z0-9_]+$", pipeline_name))):
            break
        click.echo(f"Invalid pipeline name: {pipeline_name}")
    
    return pipeline_name


def update_databricks_yml(existing_db_file_path, new_db_file_path, project_name, pipeline_name, cluster_id_dev):
    """_summary_

    Args:
        db_yml_path (_type_): _description_
        project_name (_type_): _description_
        pipeline_name (_type_): _description_
        cluster_id_dev (_type_): _description_
    """

    workflow_key = f"bundle_{project_name}_{pipeline_name}"

    with open(new_db_file_path, encoding='utf-8') as f:
        new_config = yaml.safe_load(f)

    new_dev_job = new_config['targets']['dev']['resources']['jobs'][workflow_key]
    new_dev_job['tasks'][0]['existing_cluster_id'] = cluster_id_dev

    new_qa_job = new_config['targets']['qa']['resources']['jobs'][workflow_key]

    new_prod_job = new_config['targets']['prod']['resources']['jobs'][workflow_key]

    with open(existing_db_file_path, encoding='utf-8') as f:
        existing_config = yaml.safe_load(f)

    existing_config['targets']['dev']['resources']['jobs'][workflow_key] = new_dev_job
    existing_config['targets']['qa']['resources']['jobs'][workflow_key] = new_qa_job
    existing_config['targets']['prod']['resources']['jobs'][workflow_key] = new_prod_job

    with open(existing_db_file_path, mode='w', encoding='utf-8') as f:
        yaml.dump(existing_config, f, default_flow_style=False, sort_keys=False)


def create_new_pipeline():
    """_summary_
    """
    project_root_path = prompt_project_root_path()
    template_zip_path = prompt_template_zip_path()
    pipeline_name = prompt_new_pipeline_name()
    author_email = prompt_author_email()
    db_cluster_id_dev = prompt_databricks_cluster_id('Dev')

    project_name = get_project_name(project_root_path)
    extracted_file_path = os.path.join(project_root_path, '.adm_tmp')

    with ZipFile(template_zip_path, 'r') as zip_file:
        zip_file.extractall(extracted_file_path)
        click.echo(f"Extracted folders and files to {extracted_file_path}")

    replace_placeholders({
        "project_root_path": project_root_path,
        "extracted_file_path": extracted_file_path,
        "author_email": author_email,
        "project_name": project_name,
        "pipeline_config_folder": pipeline_name,
        "pipeline_name": pipeline_name
    }, False)

    # Copy pipeline config folder to project
    src_path_p = os.path.join(extracted_file_path, 'src', pipeline_name)
    dest_path_p = os.path.join(project_root_path, 'src', pipeline_name)
    shutil.move(src_path_p, dest_path_p)
    print(f"Added pipeline config files to {dest_path_p}")

    # Copy new workflow file to project
    new_workflow_file_name = f"bundle_{project_name}_{pipeline_name}.yml"
    src_path_w = os.path.join(extracted_file_path, 'workflows', new_workflow_file_name)
    dest_path_w = os.path.join(project_root_path, 'workflows', new_workflow_file_name)
    shutil.move(src_path_w, dest_path_w)
    print(f"Added new workflow file {new_workflow_file_name} to {dest_path_w}")

    update_databricks_yml(
        os.path.join(project_root_path, 'databricks.yml'),
        os.path.join(extracted_file_path, 'databricks.yml'),
        project_name,
        pipeline_name,
        db_cluster_id_dev
    )
    print(f"Updated databricks.yml to add new entries for new pipeline {pipeline_name}")

    # Delete the temporary working folder
    shutil.rmtree(extracted_file_path)
