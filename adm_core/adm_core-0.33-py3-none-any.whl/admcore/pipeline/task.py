"""_summary_
"""

import importlib
from loguru import logger
from dynaconf import Dynaconf
import admcore.utils as ut


def run_task(task_name: str, pl_conf: Dynaconf):
    """_summary_

    Args:
        task_name (str): _description_
        pl_conf (Dynaconf): _description_
    """

    if task_name in pl_conf.tasks and pl_conf.tasks[task_name].enable is True:
        logger.info(f"task '{task_name}' started")

        task_conf = ut.AdmConfig.load_config_file(
            config_file_path=pl_conf.tasks[task_name].config_file_path,
            session_variables=pl_conf.session_variables
        )

        for action in task_conf.actions:
            if 'enable' in action and action.enable:
                logger.info(f"Action '{action.name}' started")

                module_name = action.module_file_path.split(':')[0]
                function_name = action.module_file_path.split(':')[1]

                module = importlib.import_module(
                    module_name
                )
                function = getattr(module, function_name)
                function(action, task_conf, pl_conf)

                logger.info(f"Action '{action.name}' finished")
            else:
                logger.info(f"Acton '{action.name}' skipped")

        logger.info(f"task '{task_name}' finished ****")
    else:
        logger.info(f"task '{task_name}' skipped ****")
