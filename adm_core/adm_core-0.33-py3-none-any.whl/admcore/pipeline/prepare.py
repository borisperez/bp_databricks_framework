"""_summary_
"""
from loguru import logger
from datetime import datetime
from dynaconf import Dynaconf
import admcore.utils as ut


def prepare(
        runtime_env: str,
        project_root_path: str,
        env_file_path: str,
        pl_file_path: str
) -> Dynaconf:
    """_summary_

    Args:
        runtime_env (str): _description_
        project_root_path (str): _description_
        env_file_path (str): _description_
        pl_file_path (str): _description_

    Returns:
        Dynaconf: _description_
    """

    logger.info("Prepare started")

    # Load environment variables
    ut.AdmConfig.load_sys_env_var(
        runtime_env=runtime_env,
        project_root_path=project_root_path,
        env_file_path=env_file_path,
        env_switcher="MFL_RUNTIME_ENV",
        envvar_prefix="MFL"
    )

    # Create batch_id
    batch_id = datetime.now().strftime("%Y-%m-%d-%H-%M-%S-%f")

    # Parse pipeline config file
    session_variables = {
        'batch_id': batch_id
    }

    pl_conf = ut.AdmConfig.load_config_file(
        config_file_path=pl_file_path,
        session_variables=session_variables
    )

    #pl_conf.session_variables['enterprise_job_id'] = pl_conf.info.enterprise_id

    logger.info("Prepare finished")

    return pl_conf
