"""_summary_
"""

import os
import sys
import argparse
from loguru import logger

import admcore.utils as ut
import admcore.pipeline as pl


def run_pipeline(
        runtime_env: str,
        project_root_path: str,
        environment_file_path:str,
        pipeline_file_path: str
):
    """_summary_

    Args:
        runtime_env (str): _description_
        project_root_path (str): _description_
        environment_file_path (str): _description_
        pipeline_file_path (str): _description_
    """

    # Run task "prepare"
    pl_conf = pl.prepare(
        runtime_env=runtime_env,
        project_root_path=project_root_path,
        env_file_path=environment_file_path,
        pl_file_path=pipeline_file_path
    )

    # Configure the logger
    # Remove default handler
    logger.remove()
    logging_level = os.getenv("MFL_LOGGING_LEVEL") if os.getenv("MFL_LOGGING_LEVEL") else 'INFO'
    logger.add(sys.stdout, level=logging_level)

    logger.info(f"Pipeline '{pl_conf.info.enterprise_id}'started")

    # Run task "before"
    pl.run_task('before', pl_conf)

    # Run task for loading bronze tables
    pl.run_task('load_bronze', pl_conf)

    pl.run_task('quality_check', pl_conf)

    # Run task for loading tables in enrich schema in silver catalog
    pl.run_task('load_silver_enrich', pl_conf)

    # Run task for loading tables in dim and fact schema in silver catalog
    pl.run_task('load_silver_final', pl_conf)

    # Run task for loading tables in gold catalog
    pl.run_task('load_gold', pl_conf)

    # Run task after
    pl.run_task('after', pl_conf)

    # Run task clean
    pl.run_task('clean', pl_conf)

    # Run task report
    pl.run_task('report', pl_conf)


def main():
    """_summary_

    Raises:
        ae: _description_
        e: _description_
    """

    parser = argparse.ArgumentParser()

    parser.add_argument(
        '--runtime_env',
        type=str,
        metavar='runtime_env',
        required=True,
        help='Runtime environment.'
    )

    parser.add_argument(
        '--project_file_root_path',
        type=str,
        metavar='project_file_root_path',
        required=True,
        help='Project file root path'
    )

    parser.add_argument(
        '--environment_file_path',
        type=str,
        metavar='environment_file_path',
        required=True,
        help='Path to the environment config file'
    )

    parser.add_argument(
        '--pipeline_file_path',
        type=str,
        metavar='pipeline_file_path',
        required=True,
        help='Path of your pipeline file with file name'
    )
    args = parser.parse_args()

    try:
        run_pipeline(
            runtime_env=args.runtime_env,
            project_root_path=args.project_file_root_path,
            environment_file_path=args.environment_file_path,
            pipeline_file_path=args.pipeline_file_path
        )
    except ut.AdmError as ae:
        logger.error(ae)
        raise ae
    except Exception as e:
        logger.error(e)
        raise e


if __name__ == "__main__":
    main()
