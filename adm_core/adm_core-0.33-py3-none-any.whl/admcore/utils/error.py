"""_summary_
"""


class AdmError(Exception):
    """_summary_

    Args:
        Exception (_type_): _description_
    """
