"""ADM module for creating SparkSession to make sure it works both on Databricks and locally
"""
import os
import shutil

from loguru import logger

from delta import DeltaTable
from pyspark.sql import (
    SparkSession,
    DataFrame
)

import admcore.utils as ut


class AdmSpark:
    """_summary_

    Returns:
        _type_: _description_
    """

    @classmethod
    def get_spark_session(cls) -> SparkSession:
        """Create/get a SparkSession, dynamically adjusting for Databricks environment.

        Returns:
            SparkSession: The created SparkSession object.
        """
        try:
            # pylint: disable="C0415"
            # pylint: disable="W0611"
            import databricks.sdk.dbutils # type: ignore
            logger.info("get_spark_session: Running in Databricks")
            return SparkSession.builder.getOrCreate()
        except ImportError:
            logger.info("get_spark_session: Running locally")

            catalog_list = [v for k, v in os.environ.items() if k.startswith('MFL_CAT_')]

            spark_builder = (
                SparkSession.Builder()
                    .appName(name='LocalUnitTest')
                    .master("local[*]")
                    .config(
                        "spark.jars.packages",
                        "io.delta:delta-spark_2.12:3.2.1,io.unitycatalog:unitycatalog-spark_2.12:0.2.1"
                    )
                    .config(
                        "spark.sql.extensions",
                        "io.delta.sql.DeltaSparkSessionExtension"
                    )
                    .config(
                        "spark.sql.catalog.spark_catalog",
                        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
                    )
            )

            for catalog in catalog_list:
                (
                    spark_builder
                        .config(f"spark.sql.catalog.{catalog}", "io.unitycatalog.spark.UCSingleCatalog")
                        .config(f"spark.sql.catalog.{catalog}.uri", "http://localhost:8080")
                        .config(f"spark.sql.catalog.{catalog}.token", "")
                )

            return spark_builder.getOrCreate()
    
    @classmethod
    def get_delta_table(cls, table_name):
        """_summary_

        Args:
            table_name (_type_): _description_

        Returns:
            _type_: _description_
        """

        sp = AdmSpark.get_spark_session()

        if os.environ["MFL_RUNTIME_ENV"] != 'local':
            # Running on Databricks
            delta_table = DeltaTable.forName(sp, table_name)
        else:
            # Running locally
            delta_table_path = f'{os.environ["MFL_LOCAL_DELTA_TABLE_PATH"]}/{table_name}'
            delta_table = DeltaTable.forPath(ut.AdmSpark.get_spark_session(), delta_table_path)

        return delta_table

    @classmethod
    def replace_invalid_chars_in_col_names(
        cls,
        df: SparkSession,
        invalid_chars="['$,;{}()\n\t= ]./\\",
        replace_with: str='_'
    ) -> DataFrame:
        """_summary_

        Args:
            df (SparkSession): _description_
            invalid_chars (list[str], optional): _description_. Defaults to "[',;{}()\n\t= ].".
            replace_with (str, optional): _description_. Defaults to '_'.

        Returns:
            DataFrame: _description_
        """
        cleaned_columns = [
            c.translate({ord(i): replace_with for i in invalid_chars}) for c in df.columns
        ]
        df = df.toDF(*cleaned_columns)

        return df

    @classmethod
    def df_to_table_overwrite(
        cls,
        df: DataFrame,
        table_name: str
    ):
        """_summary_

        Args:
            sp (SparkSession): _description_
            df (DataFrame): _description_
            table_name (str): _description_
        """
        df = AdmSpark.replace_invalid_chars_in_col_names(df)

        if os.environ["MFL_RUNTIME_ENV"] != 'local':
            (
                df.write
                    .mode("overwrite")
                    .format("delta")
                    .saveAsTable(table_name)
            )
        else:
            # "overwrite" mode is restricted in External table. Just delete the table first.
            delta_table_path = f'{os.environ["MFL_LOCAL_DELTA_TABLE_PATH"]}/{table_name}'
            delta_table = DeltaTable.forPath(ut.AdmSpark.get_spark_session(), delta_table_path)

            delta_table.delete()
            (
                df.write
                    .option("path", delta_table_path)
                    .mode("overwrite")
                    .format("delta")
                    .saveAsTable(table_name)
            )

    @classmethod
    def df_to_table_replace(
        cls,
        df: DataFrame,
        table_name: str
    ):
        """_summary_

        Args:
            sp (SparkSession): _description_
            df (DataFrame): _description_
            table_name (str): _description_
        """
        df = AdmSpark.replace_invalid_chars_in_col_names(df)

        if os.environ["MFL_RUNTIME_ENV"] != 'local':
            (
                df.write
                    .option("overwriteSchema", "true")
                    .mode("overwrite")
                    .format("delta")
                    .saveAsTable(table_name)
            )
        else:
            # Note: io.unitycatalog package bug: Option overwriteSchema='true' not working. So drop the table first
            sp = AdmSpark.get_spark_session()
            local_table_storage_path = f'{os.environ["MFL_LOCAL_DELTA_TABLE_PATH"]}/{table_name}'
            if sp.catalog.tableExists(tableName=table_name):
                sp.sql(f"DROP TABLE {table_name}")
                # Clean local storage since io.unitycatalog package doesn't delete it
                shutil.rmtree(local_table_storage_path)

            (
                df.write
                    .option("overwriteSchema", "true")
                    .option("path", local_table_storage_path)
                    .mode("overwrite")
                    .format("delta")
                    .saveAsTable(table_name)
            )

    @classmethod
    def df_to_table_append(
        cls,
        df: DataFrame,
        table_name: str
    ):
        """_summary_

        Args:
            sp (SparkSession): _description_
            df (DataFrame): _description_
            table_name (str): _description_
        """
        df = AdmSpark.replace_invalid_chars_in_col_names(df)

        if os.environ["MFL_RUNTIME_ENV"] != 'local':
            sp = AdmSpark.get_spark_session()
            if sp.catalog.tableExists(tableName=table_name):
                # Just append data
                (
                    df.write
                        .mode("append")
                        .format("delta")
                        .saveAsTable(table_name)
                )
            else:
                # Create table and write data
                (
                    df.write
                        .option("overwriteSchema", "true")
                        .mode("overwrite")
                        .format("delta")
                        .saveAsTable(table_name)
                )
        else:
            sp = AdmSpark.get_spark_session()
            local_table_storage_path = f'{os.environ["MFL_LOCAL_DELTA_TABLE_PATH"]}/{table_name}'
            if sp.catalog.tableExists(tableName=table_name):
                (
                    df.write
                        .option("path", local_table_storage_path)
                        .mode("append")
                        .format("delta")
                        .saveAsTable(table_name)
                )
            else:
                (
                    df.write
                        .option("overwriteSchema", "true")
                        .option("path", local_table_storage_path)
                        .mode("overwrite")
                        .format("delta")
                        .saveAsTable(table_name)
                )

    @classmethod
    def df_to_table_upsert(cls, df: DataFrame, keys: list[str], table_name: str):
        """_summary_

        Args:
            df (DataFrame): _description_
            keys (list[str]): _description_

        Raises:
            ut.AdmError: _description_

        Returns:
            _type_: _description_
        """
        sp = AdmSpark.get_spark_session()

        if os.environ["MFL_RUNTIME_ENV"] != 'local':
            table = DeltaTable.forName(sp, table_name)
        else:
            table = DeltaTable.forPath(
                sp, f'{os.environ["MFL_LOCAL_DELTA_TABLE_PATH"]}/{table_name}'
            )

        condition = ' and '.join(['t.' + x + '=s.' + x for x in df.columns if x in keys])
        if len(condition) == 0:
            raise ut.AdmError(
                "Merge condition is empty. Please check if you've configured correct upsert keys."
            )

        (
            table.alias('t')
                .merge(
                    df.alias('s'),
                    condition
                )
                .whenMatchedUpdateAll()
                .whenNotMatchedInsertAll()
                .execute()
        )

    @classmethod
    def create_dataframe_from_dict(cls, data_dict):
        """
        Create a PySpark DataFrame from a dictionary.

        Parameters:
        spark (SparkSession): The SparkSession object.
        data_dict (dict): The dictionary to convert to a DataFrame. 
                        If the values are lists, they represent multiple rows.
                        If the values are single values, they represent a single row.

        Returns:
        DataFrame: A PySpark DataFrame created from the dictionary.
        """
        sp = AdmSpark.get_spark_session()

        if all(isinstance(value, list) for value in data_dict.values()):
            # Case 1: Dictionary values are lists (multiple rows)
            if len(set(map(len, data_dict.values()))) != 1:
                raise ut.AdmError(
                    "All columns in the dictionary must have the same number of elements."
                )
            rows = list(zip(*data_dict.values()))
            columns = list(data_dict.keys())
            df = sp.createDataFrame(rows, schema=columns)
        else:
            # Case 2: Dictionary values are single values (single row)
            rows = [tuple(data_dict.values())]
            columns = list(data_dict.keys())
            df = sp.createDataFrame(rows, schema=columns)

        return df
