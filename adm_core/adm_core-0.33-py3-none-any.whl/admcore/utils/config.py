"""_summary_
"""

import os
from dynaconf import Dynaconf

import admcore.utils as ut


class AdmConfig:
    """_summary_
    """
    def __init__(self):
        pass

    @staticmethod
    def load_sys_env_var(
        runtime_env: str,
        project_root_path: str,
        env_file_path: str,
        env_switcher: str = "MFL_RUNTIME_ENV",
        envvar_prefix: str = "MFL"
    ):
        """_summary_

        Args:
            runtime_env (str): _description_
            project_root_path (str): _description_
            env_file_path (str): _description_
            env_switcher (str, optional): _description_. Defaults to "MFL_RUNTIME_ENV".
            envvar_prefix (str, optional): _description_. Defaults to "MFL".
        """
        os.environ["MFL_RUNTIME_ENV"] = runtime_env
        os.environ["MFL_PROJECT_FILE_ROOT_PATH"] = project_root_path

        # Check if env_file_path exists
        if os.path.isfile(env_file_path) is False:
            raise ut.AdmError(f"Invalid env_file_path: {env_file_path}")

        mfl_env_var = Dynaconf(
            settings_files=[env_file_path],
            envvar_prefix=envvar_prefix,
            environments=True,
            env_switcher=env_switcher
        )

        for key, value in mfl_env_var.as_dict().items():
            os.environ[f"{key.upper()}"] = str(value)

    @staticmethod
    def load_config_file(
            config_file_path: str,
            session_variables: dict
    ) -> Dynaconf:
        """_summary_

        Args:
            config_file_path (str): _description_
            session_variables (dict): items in session_variables can be used 
                in string substitution in conf file such as "@format {this.session_variables.batch_id}" 

        Returns:
            Dynaconf: _description_
        """
        if os.path.isfile(config_file_path) is False:
            raise ut.AdmError(f"Invalid config_file_path: {config_file_path}")

        config_obj = Dynaconf()
        config_obj.session_variables = session_variables
        config_obj.load_file(
            path=[config_file_path]
        )

        return config_obj
