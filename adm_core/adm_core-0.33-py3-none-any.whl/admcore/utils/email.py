"""This module keeps all functions for sending notification emails
"""

import json
import requests

from loguru import logger

import admcore.utils as ut


class AdmEmail:
    """_summary_
    """
    def __init__(
            self,
            recipients: list[str],
            subject: str,
            body: str
    ):
        self.recipients = recipients
        self.subject = subject
        self.body = body

    def send_by_logic_app(self):
        """This method sends email by using the existing Azure logic app 
        of sending email used in Synapse pipelines
        """
        url = "https://azure-notifications-lapp.azurewebsites.net:443/api/Wf_PipelineStartCompletionFailureNotification/triggers/manual/invoke?api-version=2022-05-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=5M5xbfCR35-FDkWTsN9wTF1nPMuicpS_Xo88CIG0J74"

        payload = {
            "EmailMessage" : self.body,
            "EmailReceiver": ",".join(self.recipients),
            "EmailSubject": self.subject
        }

        headers = {
            "Content-Type": "application/json"
        }

        try:
            response = requests.post(url, data=json.dumps(payload), headers=headers, timeout=10)
            if response.status_code not in [200, 201, 202]:
                logger.error("Request failed with status code:", response.status_code)
                logger.error("Error response:", response.text)
                raise ut.AdmError("Sending Email failed")
        except requests.exceptions.RequestException as e:
            raise e
